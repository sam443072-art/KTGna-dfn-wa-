"""
utils/webhook_sender.py - Gestor de envíos a Discord Webhooks.
"""

import requests
import io
from PIL import Image

class WebhookSender:
    """Clase estática para manejar envíos de texto e imagen a Discord."""
    
    @staticmethod
    def send_text(webhook_url: str, text: str) -> bool:
        if not webhook_url: return False
        try:
            r = requests.post(webhook_url, json={"content": text}, timeout=10)
            return r.status_code < 400
        except: return False

    @staticmethod
    def send_with_image(webhook_url: str, text: str, pil_img: Image.Image, filename: str = "capture.png") -> bool:
        if not webhook_url: return False
        try:
            img_byte_arr = io.BytesIO()
            pil_img.save(img_byte_arr, format='PNG')
            img_byte_arr.seek(0)
            
            files = {'file': (filename, img_byte_arr, 'image/png')}
            payload = {'content': text}
            
            r = requests.post(webhook_url, data=payload, files=files, timeout=15)
            return r.status_code < 400
        except: return False
