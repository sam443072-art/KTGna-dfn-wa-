"""
utils/event_logger.py - Formateador y guardado ligero de eventos para trabajadores.
"""

import os
import json
from datetime import datetime
from PIL import Image
from typing import Optional

class EventLogger:
    """Implementa el sistema básico de anotación de eventos para el LogWorker."""
    
    def __init__(self, base_dir: str = "logs"):
        self.base_dir = os.path.join(os.getcwd(), base_dir)
        if not os.path.exists(self.base_dir):
            os.makedirs(self.base_dir)
        
        # Subdirectorio de capturas
        self.img_dir = os.path.join(self.base_dir, "images")
        if not os.path.exists(self.img_dir):
            os.makedirs(self.img_dir)
            
    def save_event(self, event_type: str, text: str, image: Optional[Image.Image] = None, save_image: bool = True):
        """
        Formatea y guarda el evento. Compatible con la firma del LogWorker.
        """
        from engine.local_event_logger import LocalEventLogger
        
        # Aprovechar el logger de motor que ya restauramos para no duplicar código
        # pero manteniendo la firma solicitada por el worker.
        logger = LocalEventLogger(self.base_dir)
        logger.save_event(event_type, text, image, save_image)
