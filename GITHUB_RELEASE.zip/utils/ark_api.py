"""
utils/ark_api.py - Consulta de datos oficiales de servidores ASA.
"""

import requests
import time

class ArkAPI:
    """Utilidad para obtener información de servidores desde el CDN de ARK."""
    
    CDN_URL = "https://cdn2.arkdedicated.com/servers/asa/officialserverlist.json"
    _cache = None
    _last_fetch = 0
    _cache_ttl = 60 # 1 minuto de caché para no saturar
    
    @classmethod
    def get_server_stats(cls, server_number: str) -> str:
        """
        Busca el servidor por número y retorna el string de población "X/Y".
        Si no lo encuentra o hay error, retorna "Unknown population".
        """
        if not server_number:
            return "Server number not set"
            
        data = cls._fetch_data()
        if not data:
            return "Could not fetch server list"
            
        try:
            # Buscar el servidor que contenga el número en su nombre
            # Los nombres suelen ser "NA-PVP-Official-TheCenter1234"
            for server in data:
                name = server.get("Name", "")
                if server_number in name:
                    players = server.get("NumPlayers", 0)
                    max_players = server.get("MaxPlayers", 70)
                    return f"{players}/{max_players}"
        except Exception as e:
            print(f"[ARK API ERROR] {e}")
            
        return "Server not found in list"

    @classmethod
    def _fetch_data(cls):
        """Descarga el JSON del CDN con caché simple."""
        now = time.time()
        if cls._cache and (now - cls._last_fetch < cls._cache_ttl):
            return cls._cache
            
        try:
            response = requests.get(cls.CDN_URL, timeout=10)
            if response.status_code == 200:
                cls._cache = response.json()
                cls._last_fetch = now
                return cls._cache
        except Exception as e:
            print(f"[ARK API FETCH ERROR] {e}")
            
        return cls._cache if cls._cache else []
