"""
utils/ntfy_notifier.py - Integración con ntfy.sh para alertas móviles.
"""

import requests

class NtfyNotifier:
    """Implementa notificaciones rápidas a través de ntfy.sh con debug mejorado."""
    
    @staticmethod
    def send(topic: str, message: str, title: str = "ARK Monitor", priority: str = "default", tags: str = None):
        if not topic: return False, "No Topic"
        
        # Limpiar topic de espacios o barras iniciales
        topic = topic.strip().lstrip("/")
        url = f"https://ntfy.sh/{topic}"
        
        # Cabeceras estándar de ntfy
        headers = {
            "Title": title,
            "Priority": priority,
            "X-Priority": priority, # Para compatibilidad máxima
            "Tags": tags if tags else ""
        }
        
        try:
            # Enviamos como data raw (utf-8)
            r = requests.post(url, data=message.encode("utf-8"), headers=headers, timeout=10)
            if r.status_code == 200:
                return True, "200 OK"
            else:
                return False, f"Status {r.status_code}: {r.text[:50]}"
        except Exception as e:
            return False, str(e)[:50]

    @staticmethod
    def send_warning(topic: str, message: str, title: str = "Tribe Priority Alert"):
        return NtfyNotifier.send(topic, f"⚠️ {message}", title=title, priority="high", tags="warning,loud_sound")

    @staticmethod
    def send_error(topic: str, message: str, title: str = "SECURITY BREACH DETECTED"):
        # Usamos el icono en los tags para no romper las cabeceras HTTP
        return NtfyNotifier.send(topic, f"🚨 {message}", title=title, priority="max", tags="heavy_exclamation_mark,rotating_light")

    @staticmethod
    def send_success(topic: str, message: str, title: str = "Tribe Activity"):
        return NtfyNotifier.send(topic, f"✅ {message}", title=title, priority="default", tags="white_check_mark")
