"""
utils/audio_player.py - Gestor de reproducción de audio (pygame).
"""

import os
import threading
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = 'hide'
import pygame

class AudioPlayer:
    """Clase para reproducir sonidos de alerta sin bloquear el flujo principal."""
    
    _initialized = False

    @staticmethod
    def _init():
        if not AudioPlayer._initialized:
            try:
                pygame.mixer.init()
                AudioPlayer._initialized = True
            except: pass

    @staticmethod
    def play_file(file_path: str):
        """Reproduce un archivo de audio en un hilo separado."""
        if not file_path or not os.path.exists(file_path):
            return
        
        AudioPlayer._init()
        
        def _play():
            try:
                sound = pygame.mixer.Sound(file_path)
                sound.play()
            except: pass
            
        threading.Thread(target=_play, daemon=True).start()
