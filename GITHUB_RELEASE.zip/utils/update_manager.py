"""
utils/update_manager.py - Gestor de actualizaciones automáticas desde GitHub.
"""

import requests
import os
import sys
import subprocess
import time
from typing import Optional, Tuple

class UpdateManager:
    """Implementa la lógica de verificación y descarga de actualizaciones."""
    
    CURRENT_VERSION = "8.5.2"
    REPO_BASE_URL = "https://raw.githubusercontent.com/sam443072-art/KTGna-dfn-wa-/main"
    VERSION_URL = f"{REPO_BASE_URL}/version.txt"
    UPDATE_ZIP_URL = f"{REPO_BASE_URL}/update.zip"
    
    @classmethod
    def check_for_updates(cls) -> Tuple[bool, Optional[str]]:
        """
        Consulta la versión remota y la compara con la actual.
        Retorna: (bool_si_hay_update, version_remota)
        """
        try:
            # Timeout de 5s para no bloquear el arranque del bot
            response = requests.get(cls.VERSION_URL, timeout=5)
            if response.status_code == 200:
                remote_version = response.text.strip()
                if remote_version != cls.CURRENT_VERSION:
                    # Lógica simple: si es diferente, asumimos que es actualización
                    # Se podría mejorar con comparaciones de versiones semánticas (packaging.version)
                    return True, remote_version
        except Exception as e:
            print(f"[UPDATE ERROR] Could not check version: {e}")
            
        return False, None

    @classmethod
    def download_update(cls, target_path: str = "update.zip") -> bool:
        """Descarga el paquete de actualización de GitHub."""
        try:
            response = requests.get(cls.UPDATE_ZIP_URL, timeout=30, stream=True)
            if response.status_code == 200:
                with open(target_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                return True
        except Exception as e:
            print(f"[UPDATE ERROR] Download failed: {e}")
            
        return False

    @staticmethod
    def launch_updater():
        """Lanza el script updater.py y cierra el proceso actual."""
        updater_script = "updater.py"
        if os.path.exists(updater_script):
            # Lanzamos el updater de forma independiente
            subprocess.Popen([sys.executable, updater_script])
            # Cerramos la aplicación actual de forma forzosa pero limpia
            sys.exit(0)
