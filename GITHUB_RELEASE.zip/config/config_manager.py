"""
Gestor centralizado de configuración.
Responsabilidad única: Cargar/guardar JSON con valores por defecto.
"""

import os
import json
import threading
from typing import Any, Dict, Optional


class ConfigManager:
    """Gestor de configuración con defaults y persistencia en JSON."""
    
    CONFIG_FILE = "config_monitor.json"
    
    # Valores por defecto - AQUÍ van TODOS los defaults
    DEFAULTS = {
        # Webhooks
        "log_webhook": "",
        "chat_webhook": "",
        "join_webhook": "",
        
        # Zonas de captura
        "server_number": "",
        "log_region": [773, 190, 373, 594],
        "chat_region": None,
        "crash_region": None,
        "join_region": None,
        "disconnect_region": None,
        "log_history": [],
        
        # --- CONFIG TAB: Alarma ---
        "alarm_enabled": False,
        "alarm_file": "",
        "ntfy_topic": "",
        
        # --- CONFIG TAB: Envío de foto ---
        "log_send_photo": True,
        "log_draw_border": False,
        "log_only_crop": True,
        
        # --- CONFIG TAB: Eventos @everyone ---
        "everyone_events": ["was destroyed"],
        
        # --- CONFIG TAB: Topic events (filtro por webhook) ---
        "topic_events": None,  # None = enviar todos, sino lista específica
        
        # --- CONFIG TAB: Custom keywords ---
        "custom_keywords": "",
        
        # --- CONFIG TAB: Filtrado inteligente ---
        "improved_demolish": False,
        "improved_destroyed": False,
        "improved_starved": False,
        "improved_promoted": False,
        "improved_added": False,
        "improved_uploaded": False,
        
        # --- CONFIG TAB: Guardado local ---
        "local_save_events": [],
        "local_save_image": True,
    }
    
    def __init__(self, config_file: str = CONFIG_FILE):
        """
        Inicializa el gestor de configuración.
        
        Args:
            config_file: Ruta al archivo JSON de configuración
        """
        self.config_file = config_file
        self.data: Dict[str, Any] = {}
        self._lock = threading.RLock()  # Thread-safety
        self.load()
    
    def load(self) -> Dict[str, Any]:
        """
        Carga la configuración desde JSON.
        Si no existe, crea con defaults.
        
        Returns:
            Dict con la configuración actual
        """
        with self._lock:
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, "r", encoding="utf-8") as f:
                        saved = json.load(f)
                    # Merge: defaults + saved (saved sobrescribe defaults)
                    self.data = {**self.DEFAULTS, **saved}
                    return self.data
                except Exception as e:
                    print(f"⚠️ Error reading config: {e}. Using defaults.")
                    self.data = dict(self.DEFAULTS)
                    return self.data
            else:
                # Crear con defaults
                self.data = dict(self.DEFAULTS)
                self.save()
                return self.data
    
    def save(self) -> bool:
        """
        Guarda la configuración actual en JSON.
        
        Returns:
            True si tiene éxito, False en caso de error
        """
        with self._lock:
            try:
                with open(self.config_file, "w", encoding="utf-8") as f:
                    json.dump(self.data, f, indent=2, ensure_ascii=False)
                return True
            except Exception as e:
                print(f"⚠️ Error saving config: {e}")
                return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Obtiene un valor de la configuración.
        
        Args:
            key: Clave del parámetro
            default: Valor por defecto si la clave no existe
        
        Returns:
            Valor del parámetro o default
        """
        with self._lock:
            value = self.data.get(key, default)
            # Si es dict o list, devolver copia para evitar mutaciones
            if isinstance(value, (dict, list)):
                return type(value)(value)
            return value
    
    def set(self, key: str, value: Any) -> None:
        """
        Establece un valor en la configuración.
        NO GUARDA AUTOMÁTICAMENTE (call save() después).
        
        Args:
            key: Clave del parámetro
            value: Nuevo valor
        """
        with self._lock:
            self.data[key] = value
    
    def update(self, updates: Dict[str, Any]) -> None:
        """
        Actualiza múltiples valores de una vez.
        NO GUARDA AUTOMÁTICAMENTE (call save() después).
        
        Args:
            updates: Dict con los valores a actualizar
        """
        with self._lock:
            self.data.update(updates)
    
    def get_all(self) -> Dict[str, Any]:
        """Retorna una copia de TODA la configuración."""
        with self._lock:
            return dict(self.data)
    
    def reset_to_defaults(self) -> None:
        """Resetea toda la configuración a defaults."""
        with self._lock:
            self.data = dict(self.DEFAULTS)
            self.save()
