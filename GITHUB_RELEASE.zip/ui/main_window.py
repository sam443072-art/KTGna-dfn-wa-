"""
ui/main_window.py - Ventana Principal Refactorizada
Importación estándar de ArkLogApp.
"""

import sys
import os

# Asegurar que el directorio raíz esté en el path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

# Importación directa (Punto #8 corregido)
from log_bot3 import ArkLogApp

__all__ = ['ArkLogApp']
