"""
signals.py - Adaptador para migración Qt → Flet

ANTES: Usaba PySide6.QtCore.Signal
AHORA: Usa event_bus.py pero mantiene interfaz compatible

Esta clase es una ENVOLVENTE que mapea los métodos de signals de Qt
al event_bus centralizado, facilitando la migración gradual.

Patrón:
    OLD: self.signals.console_msg.emit("msg")
    NEW: self.signals.console_msg.emit("msg")  ← MISMO CÓDIGO, menos cambios
         (pero internamente usa event_bus en lugar de Qt signals)

Para Flet puro, los workers pueden directamente usar:
    from engine.event_bus import bus
    bus.emit("log:message", msg)
"""

from engine.event_bus import bus
from typing import Callable


class Signal:
    """Adaptador de signal que usa event_bus bajo el capó."""
    
    def __init__(self, event_name: str, *arg_types):
        self.event_name = event_name
        self.arg_types = arg_types
    
    def emit(self, *args, **kwargs) -> None:
        """Emitir un evento (equivalente a Signal.emit() de Qt)."""
        bus.emit(self.event_name, *args, **kwargs)
    
    def connect(self, callback: Callable) -> None:
        """Conectar un callback (equivalente a Signal.connect() de Qt)."""
        bus.on(self.event_name, callback)
    
    def disconnect(self, callback: Callable) -> None:
        """Desconectar un callback (equivalente a Signal.disconnect() de Qt)."""
        bus.off(self.event_name, callback)


class BotSignals:
    """
    Contenedor de todas las señales de comunicación entre workers y Flet.
    
    Usa event_bus internamente pero mantiene interfaz compatible con Qt signals
    para facilitar migración gradual.
    """
    
    def __init__(self):
        """Inicializa las señales para el bus de eventos de la instancia."""
        self.console_msg = Signal("log:message", str)
        self.auto_reconnect = Signal("log:auto_reconnect")
        self.trigger_crash_recovery = Signal("log:crash_recovery")
        self.update_hud = Signal("log:update_hud", str, str)
        self.notify = Signal("log:notify", str, str) # title, message
        self.close_hud = Signal("log:close_hud")


# =====================================================
# ARQUITECTURA FINAL
# =====================================================
#
# CAPAS (Dependencias unidireccionales ↓):
#
#   Flet (UI)
#       ↓
#   event_bus.py (comunicación)
#       ↓
#   engine/ (workers + lógica)
#       ↓
#   core/ (visión + captura)
#       ↓
#   utils/ (helpers)
#   ui/tabs/ ← importa engine, core, config, utils ← Puede importar engine
#   ui/ (main_window) ← importa engine, config, ui/tabs
#   main.py ← importa config, ui
#
# VIRTUALMENTE IMPOSIBLE tener circularidad::
#
#   ✅ engine/log_worker.py puede importar core.vision
#   ✅ ui/tabs/log_tab.py puede importar engine.signals
#   ❌ engine/* NUNCA debe importar de ui/*
#   ❌ core/* NUNCA debe importar de engine/*
#
# Esto asegura una cadena de dependencias unidireccional.
