"""
ui/flet_app.py — ARK Monitor Pro v8.5 (Redesign)

Changes vs previous version:
- Vertical sidebar instead of horizontal tabs
- Full English Localization
"""

import time
import flet as ft
from datetime import datetime
import threading
import asyncio
import os, sys, json, glob, subprocess

from config.config_manager import ConfigManager
from engine.event_bus import bus
from engine.signals import BotSignals
from engine.log_worker import LogWorker
from engine.disconnect_worker import DisconnectWorker
from utils.update_manager import UpdateManager


# ─────────────────────────────────────────────
# PALETTE & CONSTANTS
# ─────────────────────────────────────────────
C_BG_BASE    = "#080a0f"
C_BG_SURFACE = "#0d1117"
C_BG_CARD    = "#111620"
C_BG_INPUT   = "#0a0e16"
C_ACCENT     = "#00e5ff"
C_ORANGE     = "#ff6b35"
C_GREEN      = "#00ff88"
C_WARNING    = "#ffb347"
C_DANGER     = "#ff3860"
C_TEXT_PRI   = "#e8eaf0"
C_TEXT_SEC   = "#6b7a99"
C_TEXT_MUTED = "#3a4560"

C_BORDER    = ft.colors.with_opacity(0.08, ft.colors.WHITE)
C_BORDER_HV = ft.colors.with_opacity(0.22, C_ACCENT)
C_ACCENT_10 = ft.colors.with_opacity(0.10, C_ACCENT)
C_ACCENT_04 = ft.colors.with_opacity(0.04, C_ACCENT)

# Tag colors
TAG_COLORS = {
    "OK":    C_GREEN,
    "LOG":   C_ACCENT,
    "EVT":   C_ORANGE,
    "ALERT": C_DANGER,
    "WARN":  C_WARNING,
    "INFO":  C_TEXT_SEC,
    "DISC":  C_ORANGE,
    "ERR":   C_DANGER,
}

def _classify_msg(msg: str):
    """Classifies a log message to assign tag + color."""
    m = msg.lower()
    if any(x in m for x in ["✅", "success", "started", "ready", "ok"]):
        return "OK", C_GREEN
    if any(x in m for x in ["🚨", "alert", "attack", "destroyed"]):
        return "ALERT", C_DANGER
    if any(x in m for x in ["💥", "evnt", "[new log]", "was killed", "day "]):
        return "EVT", C_ORANGE
    if any(x in m for x in ["⚠️", "warn", "error", "❌", "failed"]):
        return "WARN", C_WARNING
    if any(x in m for x in ["🔌", "reconnect", "[reco]"]):
        return "RECO", C_ORANGE
    if any(x in m for x in ["[log]", "[crash]", "[join]"]):
        return "LOG", C_ACCENT
    return "INFO", C_TEXT_SEC


# ─────────────────────────────────────────────
# REUSABLE COMPONENTS
# ─────────────────────────────────────────────

def make_card(*controls, padding: int = 16) -> ft.Container:
    """Card with subtle border and top accent."""
    return ft.Container(
        content=ft.Column(list(controls), spacing=10, tight=True),
        bgcolor=C_BG_CARD,
        border=ft.border.all(1, C_BORDER),
        border_radius=12,
        padding=padding,
    )


def make_section_label(text: str, color: str = C_ACCENT) -> ft.Text:
    return ft.Text(
        text,
        size=9,
        font_family="Rajdhani",
        weight=ft.FontWeight.W_700,
        color=color,
    )


def make_input(label: str, hint: str, value: str = "",
               on_change=None, password: bool = False) -> ft.TextField:
    return ft.TextField(
        label=label,
        hint_text=hint,
        value=value,
        on_change=on_change,
        password=password,
        bgcolor=C_BG_INPUT,
        border_color=C_BORDER,
        focused_border_color=ft.colors.with_opacity(0.50, C_ACCENT),
        focused_border_width=1,
        border_width=1,
        border_radius=8,
        text_style=ft.TextStyle(font_family="JetBrainsMono", size=11, color=C_TEXT_PRI),
        label_style=ft.TextStyle(font_family="Rajdhani", size=10, color=C_TEXT_MUTED, weight=ft.FontWeight.W_700),
        hint_style=ft.TextStyle(font_family="JetBrainsMono", size=10, color=C_TEXT_MUTED),
        cursor_color=C_ACCENT,
        content_padding=ft.padding.symmetric(horizontal=14, vertical=10),
    )


def make_btn_ghost(text: str, icon: str = None, on_click=None,
                   color: str = C_ACCENT) -> ft.Container:
    """Outline button with subtle hover."""
    content_controls = []
    if icon:
        content_controls.append(ft.Text(icon, size=13))
    content_controls.append(
        ft.Text(text, font_family="Rajdhani", size=12,
                weight=ft.FontWeight.W_700, color=color)
    )

    def on_hover(e):
        btn_container.bgcolor = (
            ft.colors.with_opacity(0.06, color)
            if e.data == "true" else "transparent"
        )
        btn_container.border = ft.border.all(
            1,
            ft.colors.with_opacity(0.60, color)
            if e.data == "true"
            else ft.colors.with_opacity(0.18, color)
        )
        btn_container.update()

    btn_container = ft.Container(
        content=ft.Row(content_controls, spacing=6, tight=True),
        bgcolor="transparent",
        border=ft.border.all(1, ft.colors.with_opacity(0.18, color)),
        border_radius=8,
        padding=ft.padding.symmetric(horizontal=14, vertical=9),
        on_click=on_click,
        on_hover=on_hover,
        ink=True,
    )
    return btn_container


def make_btn_primary(text_or_ctrl, icon: str = None, on_click=None) -> ft.Container:
    """Filled button with glow on hover."""
    text_ctrl = text_or_ctrl if isinstance(text_or_ctrl, ft.Control) else \
                ft.Text(text_or_ctrl, font_family="Rajdhani", size=12,
                        weight=ft.FontWeight.W_700, color="#000000")
    content_controls = []
    if icon:
        content_controls.append(ft.Text(icon, size=13))
    content_controls.append(text_ctrl)

    def on_hover(e):
        btn.shadow = (
            ft.BoxShadow(
                blur_radius=24,
                spread_radius=0,
                color=ft.colors.with_opacity(0.35, C_ACCENT),
            )
            if e.data == "true" else None
        )
        btn.update()

    btn = ft.Container(
        content=ft.Row(content_controls, spacing=6, tight=True),
        bgcolor=C_ACCENT,
        border_radius=8,
        padding=ft.padding.symmetric(horizontal=14, vertical=9),
        on_click=on_click,
        on_hover=on_hover,
        shadow=None,
        ink=True,
    )
    return btn


def make_zone_tag(region) -> ft.Container:
    """Tag with status dot and coordinates."""
    dot_color = C_ACCENT if region else C_TEXT_MUTED
    text = str(region) if region else "Not Defined"

    return ft.Container(
        content=ft.Row([
            ft.Container(
                width=5, height=5,
                bgcolor=dot_color,
                border_radius=3,
                shadow=(
                    ft.BoxShadow(blur_radius=6, spread_radius=0, color=dot_color)
                    if region else None
                ),
            ),
            ft.Text(
                text,
                font_family="JetBrainsMono",
                size=10,
                color=dot_color,
            ),
        ], spacing=6, tight=True),
        bgcolor=ft.colors.with_opacity(0.06, dot_color),
        border=ft.border.all(1, ft.colors.with_opacity(0.15, dot_color)),
        border_radius=20,
        padding=ft.padding.symmetric(horizontal=10, vertical=4),
    )


def make_console() -> ft.ListView:
    """ListView acting as a console."""
    return ft.ListView(
        expand=True,
        auto_scroll=True,
        spacing=0,
        item_extent=None,
    )


def make_log_row(ts: str, tag: str, msg: str, tag_color: str) -> ft.Row:
    return ft.Row([
        ft.Text(ts, font_family="JetBrainsMono", size=10,
                color=C_TEXT_MUTED, width=68, no_wrap=True),
        ft.Container(
            content=ft.Text(tag, font_family="JetBrainsMono", size=9,
                            color=tag_color, weight=ft.FontWeight.W_500,
                            text_align=ft.TextAlign.CENTER),
            bgcolor=f"{tag_color}1a",
            border_radius=4,
            padding=ft.padding.symmetric(horizontal=6, vertical=1),
            width=44,
        ),
        ft.Text(msg, font_family="JetBrainsMono", size=11,
                color=C_TEXT_SEC, expand=True, no_wrap=False),
    ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START)


def make_console_card(title: str, console: ft.ListView) -> ft.Container:
    """Terminal-style console card."""
    return ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.Row([
                        ft.Container(width=8, height=8, bgcolor="#ff5f57", border_radius=4),
                        ft.Container(width=8, height=8, bgcolor="#ffbd2e", border_radius=4),
                        ft.Container(width=8, height=8, bgcolor="#28c840", border_radius=4),
                    ], spacing=5),
                    ft.Text(title, font_family="JetBrainsMono", size=10, color=C_TEXT_MUTED),
                ], spacing=10),
                bgcolor=C_ACCENT_04,
                border=ft.border.only(bottom=ft.BorderSide(1, C_BORDER)),
                padding=ft.padding.symmetric(horizontal=14, vertical=10),
            ),
            ft.Container(
                content=console,
                expand=True,
                padding=ft.padding.symmetric(horizontal=14, vertical=8),
            ),
        ], spacing=0, tight=True, expand=True),
        bgcolor=C_BG_INPUT,
        border=ft.border.all(1, C_BORDER),
        border_radius=12,
        expand=True,
        clip_behavior=ft.ClipBehavior.HARD_EDGE,
    )


# ─────────────────────────────────────────────
# SIDEBAR NAV ITEM
# ─────────────────────────────────────────────

class NavItem(ft.Container):
    def __init__(self, icon: str, label: str, index: int,
                 on_select=None, active: bool = False, badge: bool = False):
        self.nav_index = index
        self._on_select = on_select
        self._active = active

        self._indicator = ft.Container(
            width=2, height=0,
            bgcolor=C_ACCENT,
            border_radius=ft.border_radius.only(top_right=2, bottom_right=2),
            shadow=ft.BoxShadow(blur_radius=8, color=C_ACCENT),
            animate=ft.Animation(200, ft.AnimationCurve.EASE_OUT),
        )

        self._bg = ft.Container(
            width=44, height=44,
            bgcolor=f"{C_ACCENT}1a" if active else "transparent",
            border=ft.border.all(1, f"{C_ACCENT}40" if active else "transparent"),
            border_radius=10,
            animate=ft.Animation(150, ft.AnimationCurve.EASE_OUT),
            content=ft.Column([
                ft.Text(icon, size=16),
                ft.Text(label, font_family="Rajdhani", size=8,
                        weight=ft.FontWeight.W_700,
                        color=C_ACCENT if active else C_TEXT_MUTED),
            ], alignment=ft.MainAxisAlignment.CENTER,
               horizontal_alignment=ft.CrossAxisAlignment.CENTER,
               spacing=2, tight=True),
        )

        badge_dot = ft.Container(
            width=7, height=7,
            bgcolor=C_GREEN,
            border_radius=4,
            shadow=ft.BoxShadow(blur_radius=6, color=C_GREEN),
            visible=badge,
            right=3, top=3,
        )

        inner = ft.Stack([self._bg, badge_dot])

        super().__init__(
            content=ft.Row([self._indicator, inner], spacing=4,
                           vertical_alignment=ft.CrossAxisAlignment.CENTER),
            on_click=self._handle_click,
            on_hover=self._handle_hover,
            padding=ft.padding.symmetric(horizontal=6, vertical=3),
        )

        if active:
            self._indicator.height = 28

    def _handle_click(self, e):
        if self._on_select:
            self._on_select(self.nav_index)

    def _handle_hover(self, e):
        if not self._active:
            self._bg.bgcolor = f"{C_ACCENT}0a" if e.data == "true" else "transparent"
            self._bg.update()

    def set_active(self, active: bool):
        self._active = active
        self._bg.bgcolor = f"{C_ACCENT}1a" if active else "transparent"
        self._bg.border = ft.border.all(1, f"{C_ACCENT}40" if active else "transparent")
        self._indicator.height = 28 if active else 0
        self._bg.update()
        self._indicator.update()


# ─────────────────────────────────────────────
# STATUS PILL
# ─────────────────────────────────────────────

class StatusPill(ft.Row):
    def __init__(self, label: str):
        self._dot = ft.Container(
            width=5, height=5,
            bgcolor=C_TEXT_MUTED,
            border_radius=3,
        )
        self._label = ft.Text(
            label,
            font_family="JetBrainsMono",
            size=9,
            color=C_TEXT_MUTED,
        )
        super().__init__(
            [self._dot, self._label],
            spacing=5,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def set_active(self, active: bool):
        color = C_GREEN if active else C_TEXT_MUTED
        self._dot.bgcolor = color
        self._dot.shadow = (
            ft.BoxShadow(blur_radius=8, spread_radius=0, color=color)
            if active else None
        )
        self._label.color = color
        try:
            self._dot.update()
            self._label.update()
        except Exception:
            pass


# ─────────────────────────────────────────────
# MAIN APP
# ─────────────────────────────────────────────

class ArkLogApp:
    def __init__(self, page: ft.Page):
        from engine.signals import BotSignals
        self.page = page
        self.signals = BotSignals()
        self.config_manager = ConfigManager()
        self.config = self.config_manager.data

        # Regions
        self.log_region        = tuple(self.config.get("log_region")) if self.config.get("log_region") else None
        self.disc_region       = tuple(self.config.get("disconnect_region")) if self.config.get("disconnect_region") else None
        
        # Coordinates
        self.reconnect_pos     = tuple(self.config.get("reconnect_pos")) if self.config.get("reconnect_pos") else None

        # Workers
        self.log_worker        = None
        self.disconnect_worker = None
        self.reconnect_worker  = None

        # Consoles (ft.ListView)
        self.log_console       = make_console()
        self.reconnect_console = make_console()

        # Status Pills (Footer)
        self._status_pills = {}
        self._status_pills["log"]  = StatusPill("LOG")
        self._status_pills["disc"] = StatusPill("WATCHER")
        self._status_pills["recon"] = StatusPill("SEQUENCE")

        # Nav items & tab contents
        self._nav_items: list[NavItem] = []
        self._tab_contents: list[ft.Container] = []
        self._current_tab = 0

        # Start message in each console
        for c, msg, color in [
            (self.log_console,       "Tribe Log System ready. Select region and start.", C_GREEN),
            (self.reconnect_console, "Reconnection System ready.", C_ORANGE),
        ]:
            c.controls.append(make_log_row(
                datetime.now().strftime("%H:%M:%S"), "OK", msg, C_GREEN
            ))

    # ── Thread-safe log ──────────────────────

    def _safe_update(self, controls):
        if not self.page: return
        async def _async_upd():
            try:
                if isinstance(controls, list):
                    for c in controls: c.update()
                else:
                    controls.update()
            except: pass
        self.page.run_task(_async_upd)

    def _add_to_console(self, console: ft.ListView, msg: str):
        if not self.page: return
        tag, color = _classify_msg(msg)
        row = make_log_row(datetime.now().strftime("%H:%M:%S"), tag, msg, color)
        async def _update_async_task():
            try:
                console.controls.append(row)
                if len(console.controls) > 300: console.controls.pop(0)
                console.update()
            except: pass
        self.page.run_task(_update_async_task)

    def _on_log_message(self, msg: str):
        m = msg.upper()
        if "[RECONNECT]" in m or "[DISCONNECT]" in m or "[HUD]" in m or "[RECO]" in m:
            target = self.reconnect_console
        else:
            target = self.log_console
        self._add_to_console(target, msg)

    def _on_notify(self, title, message):
        async def _async_notify():
            self.page.snack_bar = ft.SnackBar(
                content=ft.Row([
                    ft.Text("🔔", size=16),
                    ft.Column([
                        ft.Text(title, weight=ft.FontWeight.W_700, size=12, color=C_ACCENT),
                        ft.Text(message, size=11, color=C_TEXT_PRI),
                    ], spacing=0, tight=True)
                ], spacing=10),
                bgcolor=C_BG_CARD,
                elevation=10,
                duration=4000,
            )
            self.page.snack_bar.open = True
            self.page.update()
        self.page.run_task(_async_notify)

    def _on_auto_reconnect(self):
        self._add_to_console(self.reconnect_console,
                             "🔌 [AUTO-RECONNECT] DisconnectWorker detected disconnection, processing...")

    def _on_update_hud(self, step: str, ocr: str):
        self._add_to_console(self.reconnect_console, f"▸ {step}  OCR: {ocr}")

    def _on_close_hud(self):
        self._add_to_console(self.reconnect_console, "✅ [HUD] Successful reconnection. HUD closed.")

    # ── Build ────────────────────────────────

    def build(self) -> ft.Column:
        self.page.fonts = {
            "Rajdhani":     "https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7S-QT7pa1S1Y8.woff2",
            "JetBrainsMono":"https://fonts.gstatic.com/s/jetbrainsmono/v18/tDbY2o-flEEny0FZhsfKu5WU4xD-IQ.woff2",
        }

        bus.on("log:message",      self._on_log_message)
        bus.on("log:update_hud",   self._on_update_hud)
        bus.on("log:close_hud",    self._on_close_hud)
        bus.on("log:notify",       self._on_notify)

        self._tab_contents = [
            self._build_home_tab(),
            self._build_log_tab(),
            self._build_reconnect_tab(),
            self._build_config_tab(),
            self._build_history_tab(),
        ]

        NAV = [
            ("🏠", "Home",     True,  False),
            ("📜", "Log",      False, False),
            ("🔌", "Recon",    False, False),
        ]
        NAV_BOTTOM = [
            ("⚙️", "Settings", False, False),
            ("📁", "History",  False, False),
        ]

        for i, (icon, label, active, badge) in enumerate(NAV):
            ni = NavItem(icon, label, i, on_select=self._switch_tab,
                         active=active, badge=badge)
            self._nav_items.append(ni)

        for i, (icon, label, active, badge) in enumerate(NAV_BOTTOM):
            ni = NavItem(icon, label, len(NAV) + i, on_select=self._switch_tab,
                         active=active, badge=badge)
            self._nav_items.append(ni)

        sidebar = ft.Container(
            content=ft.Column([
                ft.Column(self._nav_items[:3], spacing=2),
                ft.Container(expand=True),
                ft.Column(self._nav_items[3:], spacing=2),
            ], expand=True, spacing=0),
            width=64,
            bgcolor=C_BG_SURFACE,
            border=ft.border.only(right=ft.BorderSide(1, C_BORDER)),
            padding=ft.padding.symmetric(vertical=12),
        )

        self._content_stack = ft.AnimatedSwitcher(
            content=self._tab_contents[0],
            transition=ft.AnimatedSwitcherTransition.FADE,
            duration=250,
            reverse_duration=150,
            switch_in_curve=ft.AnimationCurve.EASE_OUT,
            switch_out_curve=ft.AnimationCurve.EASE_IN,
            expand=True,
        )

        PILLS = [("LOG", "log"),
                 ("WATCHER", "disc"), ("SEQUENCE", "recon")]
        status_pills_row = ft.Row(spacing=16, vertical_alignment=ft.CrossAxisAlignment.CENTER)
        for label, key in PILLS:
            status_pills_row.controls.append(self._status_pills[key])

        footer = ft.Container(
            content=ft.Row([
                status_pills_row,
                ft.Container(expand=True),
                ft.Row([
                    ft.Container(
                        content=ft.Text("By TPYO", font_family="Rajdhani", size=11, weight=ft.FontWeight.W_800, color=C_ACCENT),
                        shadow=ft.BoxShadow(blur_radius=20, color=ft.colors.with_opacity(0.4, C_ACCENT))
                    ),
                    ft.Text("· v8.5", font_family="JetBrainsMono", size=9, color=C_TEXT_MUTED),
                ], spacing=4),
            ], spacing=16, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            height=36,
            bgcolor=C_BG_SURFACE,
            border=ft.border.only(top=ft.BorderSide(1, C_BORDER)),
            padding=ft.padding.symmetric(horizontal=20),
        )

        if self._current_tab == 0:
            async def run_home_seq():
                await asyncio.sleep(0.6)
                try:
                    self._home_welcome.offset = ft.Offset(0, -0.15)
                    self._home_welcome.scale = 0.78
                    self.page.update()
                    await asyncio.sleep(0.7)
                    self._home_changelog.opacity = 1
                    self._home_changelog.offset = ft.Offset(0, -0.05)
                    self.page.update()
                except: pass
            self.page.run_task(run_home_seq)
            self.page.run_task(self._check_for_updates_task)

        return ft.Column([
            self._build_titlebar(),
            ft.Row([sidebar, self._content_stack], expand=True, spacing=0, vertical_alignment=ft.CrossAxisAlignment.START),
            footer,
        ], spacing=0, expand=True)

    def _build_titlebar(self) -> ft.Container:
        self._titlebar_dot = ft.Container(width=6, height=6, bgcolor=C_TEXT_MUTED, border_radius=3, animate=ft.Animation(300, ft.AnimationCurve.EASE_OUT))
        self._title_status_ref = ft.Ref()
        discord_btn = ft.Container(
            content=ft.Row([
                ft.Icon(ft.icons.DISCORD, size=16, color=C_TEXT_SEC),
                ft.Text("Discord", font_family="Rajdhani", size=10, weight=ft.FontWeight.W_600, color=C_TEXT_SEC),
            ], spacing=6, tight=True),
            on_click=lambda _: self.page.launch_url("https://discord.gg/kv8pzA7ubc"),
            padding=ft.padding.symmetric(horizontal=12, vertical=6),
            border_radius=8,
            border=ft.border.all(1, ft.colors.with_opacity(0.1, C_TEXT_MUTED)),
            on_hover=lambda e: (
                setattr(e.control, "bgcolor", ft.colors.with_opacity(0.08, C_ACCENT) if e.data=="true" else None),
                setattr(e.control.content.controls[0], "color", C_ACCENT if e.data=="true" else C_TEXT_SEC),
                setattr(e.control.content.controls[1], "color", C_ACCENT if e.data=="true" else C_TEXT_SEC),
                e.control.update()
            ),
            tooltip="Official Support Server",
        )
        return ft.Container(
            content=ft.Row([
                ft.Text("LOG", font_family="Rajdhani", size=14, weight=ft.FontWeight.W_700, color=C_ACCENT),
                ft.Text("BOT", font_family="Rajdhani", size=14, weight=ft.FontWeight.W_400, color=C_TEXT_SEC),
                ft.Container(width=1, height=14, bgcolor=C_BORDER),
                self._titlebar_dot,
                ft.Text("OFFLINE", font_family="JetBrainsMono", size=9, color=C_TEXT_MUTED, ref=self._title_status_ref),
                ft.Container(expand=True),
                discord_btn,
            ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            height=44, bgcolor=f"{C_BG_SURFACE}f5", border=ft.border.only(bottom=ft.BorderSide(1, C_BORDER)), padding=ft.padding.only(left=20, right=14),
        )

    def _set_online(self, online: bool):
        color = C_GREEN if online else C_TEXT_MUTED
        label = "ONLINE" if online else "OFFLINE"
        self._titlebar_dot.bgcolor = color
        self._titlebar_dot.shadow = ft.BoxShadow(blur_radius=8, color=color) if online else None
        if self._title_status_ref.current:
            self._title_status_ref.current.value = label
            self._title_status_ref.current.color = color
        try: self.page.update()
        except: pass

    def _switch_tab(self, index: int):
        if index == self._current_tab: return
        self._nav_items[self._current_tab].set_active(False)
        self._nav_items[index].set_active(True)
        self._current_tab = index
        self._content_stack.content = self._tab_contents[index]
        self.page.update()

    def _make_tab_header(self, title: str, subtitle: str) -> ft.Container:
        return ft.Container(
            content=ft.Row([
                ft.Container(content=ft.Text(title, font_family="Rajdhani", size=20, weight=ft.FontWeight.W_700, color=C_TEXT_PRI),
                             border=ft.border.only(bottom=ft.BorderSide(2, C_ACCENT)), padding=ft.padding.only(bottom=12)),
                ft.Text(subtitle, font_family="Rajdhani", size=11, color=C_TEXT_SEC),
            ], spacing=16, vertical_alignment=ft.CrossAxisAlignment.END),
            border=ft.border.only(bottom=ft.BorderSide(1, C_BORDER)), padding=ft.padding.only(left=24, right=24, top=18, bottom=16),
        )

    def _build_home_tab(self) -> ft.Container:
        import os
        try: username = os.getlogin()
        except: username = "User"
        self._home_welcome = ft.Column([
            ft.Text("WELCOME,", font_family="Rajdhani", size=32, weight=ft.FontWeight.BOLD, color=C_ACCENT),
            ft.Text(username.upper(), font_family="Rajdhani", size=48, weight=ft.FontWeight.W_900, color=C_TEXT_PRI),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, animate_opacity=600, animate_offset=600, animate_scale=600, offset=ft.Offset(0, 0))
        self._home_changelog = ft.Column([
            ft.Text("CHANGELOG v8.5 — GLOBAL UPDATE", font_family="Rajdhani", size=18, weight=ft.FontWeight.W_700, color=C_ACCENT),
            ft.Container(height=2, width=80, bgcolor=ft.colors.with_opacity(0.3, C_ACCENT), border_radius=1),
            ft.Column([
                ft.Text("• LogBot System Optimization & Real-time Tracking.", size=12, color=C_TEXT_SEC),
                ft.Text("• Premium UI Design & High-End Dynamic Transitions.", size=12, color=C_TEXT_SEC),
                ft.Text("• Enhanced Automatic Join & Shield Security Protocols.", size=12, color=C_TEXT_SEC),
                ft.Text("• Puto el que lo lea.", size=12, color=C_TEXT_SEC),
                ft.Text("• Easy Autojoin.", size=12, color=C_TEXT_SEC),
            ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        ], visible=True, opacity=0, animate_opacity=800, animate_offset=800, offset=ft.Offset(0, 0.1), spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        
        # Banner de actualización (oculto por defecto)
        self._update_ver_text = ft.Text("Version v0.0 is ready for download.", size=11, color=C_TEXT_PRI)
        self._update_banner = ft.Container(
            content=ft.Row([
                ft.Text("🚀", size=20),
                ft.Column([
                    ft.Text("NEW UPDATE AVAILABLE!", weight="bold", size=13, color=C_ACCENT),
                    self._update_ver_text,
                ], spacing=0, tight=True, expand=True),
                make_btn_primary("DOWNLOAD & INSTALL", ft.icons.DOWNLOAD, on_click=self._on_click_update)
            ]),
            bgcolor=C_BG_CARD,
            border=ft.border.all(1, ft.colors.with_opacity(0.3, C_ACCENT)),
            border_radius=12,
            padding=16,
            width=500,
            offset=ft.Offset(0, 1), # Fuera de pantalla abajo
            animate_offset=ft.Animation(600, ft.AnimationCurve.EASE_OUT_BACK),
            visible=False
        )

        return ft.Container(content=ft.Column([
            ft.Container(height=80), 
            self._home_welcome, 
            ft.Container(height=40), 
            self._home_changelog,
            ft.Container(height=40),
            self._update_banner
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, alignment=ft.MainAxisAlignment.CENTER, expand=True), expand=True, padding=ft.padding.all(40), animate_opacity=400, key="home_tab")

    async def _check_for_updates_task(self):
        """Tarea asíncrona para buscar actualizaciones."""
        await asyncio.sleep(3) # Esperar a que la UI se estabilice
        has_update, remote_ver = UpdateManager.check_for_updates()
        if has_update:
            self._update_ver_text.value = f"Version v{remote_ver} is ready for download."
            self._update_banner.visible = True
            self._update_banner.update()
            await asyncio.sleep(0.1)
            self._update_banner.offset = ft.Offset(0, 0)
            self._update_banner.update()

    def _on_click_update(self, e):
        """Maneja la descarga y el reinicio."""
        e.control.disabled = True
        e.control.content.controls[1].value = "DOWNLOADING..."
        e.control.update()
        
        def _job():
            if UpdateManager.download_update():
                self._add_to_console(self.log_console, "✅ Update downloaded. Restarting via Updater...")
                time.sleep(1)
                UpdateManager.launch_updater()
            else:
                self._add_to_console(self.log_console, "❌ Update download failed.")
                e.control.disabled = False
                e.control.content.controls[1].value = "RETRY DOWNLOAD"
                e.control.update()
        
        threading.Thread(target=_job, daemon=True).start()

    def _build_log_tab(self) -> ft.Container:
        self._log_zone_row = make_zone_tag(self.log_region)
        self._log_btn_text = ft.Text("START LOG", size=12, weight=ft.FontWeight.W_600)
        self._log_start_btn = make_btn_primary(self._log_btn_text, "▶", on_click=lambda e: self._toggle_log(e.control))
        zone_btn = make_btn_ghost("Select Region", "📐", on_click=lambda e: self._select_zone("log"))
        
        server_input = make_input("SERVER NUMBER", "Ex: 4055", value=self.config.get("server_number", ""), on_change=lambda e: self._update_config("server_number", e.control.value))
        webhook_input = make_input("DISCORD WEBHOOK", "https://...", value=self.config.get("log_webhook", ""), on_change=lambda e: self._update_config("log_webhook", e.control.value))
        
        content = ft.Column([
            self._make_tab_header("Tribe Log", "Real-time monitoring of ARK log"),
            ft.Container(content=ft.Column([
                make_card(make_section_label("CONFIGURATION"), server_input, webhook_input, ft.Row([zone_btn, self._log_start_btn], spacing=10), self._log_zone_row),
                make_console_card("Console — Log Worker", self.log_console),
            ], spacing=14, expand=True), expand=True, padding=ft.padding.all(20))
        ], spacing=0, expand=True)
        return ft.Container(content=content, expand=True, animate_opacity=300, key="log_tab")


    def _build_reconnect_tab(self) -> ft.Container:
        self._disc_zone_row = make_zone_tag(self.disc_region)
        server_input = make_input("SERVER NUMBER", "Ex: 1234", value=self.config.get("server_number", ""), on_change=lambda e: self._update_config("server_number", e.control.value))
        self._disc_btn_text = ft.Text("START WATCHER", size=12, weight=ft.FontWeight.W_700, color="#000")
        self._disc_start_btn = make_btn_primary(self._disc_btn_text, "▶", on_click=lambda e: self._toggle_disconnect(e.control))
        force_btn = ft.Container(content=ft.Row([ft.Text("🔌", size=16), ft.Text("FORCE RECONNECT NOW", font_family="Rajdhani", size=13, weight=ft.FontWeight.W_700, color=C_TEXT_PRI)], spacing=10, tight=True), bgcolor=C_DANGER, border_radius=8, padding=ft.padding.symmetric(horizontal=20, vertical=12), on_click=self._toggle_reconnect, shadow=ft.BoxShadow(blur_radius=20, color=f"{C_DANGER}40"), ink=True)
        self.calib_tag_ref = ft.Text(f"📍 Position: {self.reconnect_pos}" if self.reconnect_pos else "📍 Not Calibrated", font_family="JetBrainsMono", size=10, color=C_ACCENT if self.reconnect_pos else C_TEXT_MUTED)
        calib_btn = make_btn_ghost("Calibrate (MOUSE)", "🎯", color=C_ACCENT, on_click=self._start_calibration)
        content = ft.Column([
            self._make_tab_header("Automatic Reconnection", "Detects disconnections and reconnects"),
            ft.Container(content=ft.Column([
                make_card(make_section_label("SERVER NUMBER", C_ACCENT), server_input),
                make_card(make_section_label("CLICK CALIBRATION", C_ACCENT), ft.Text("Place mouse over button and calibrate.", size=11, color=C_TEXT_SEC), ft.Row([calib_btn, self.calib_tag_ref], spacing=15)),
                make_card(make_section_label("DISCONNECT MONITOR", C_ORANGE), ft.Row([make_btn_ghost("Select Region", "📐", color=C_ORANGE, on_click=lambda e: self._select_zone("disc")), self._disc_start_btn], spacing=10), self._disc_zone_row),
                make_card(make_section_label("MANUAL CONTROL", C_DANGER), force_btn),
                make_console_card("Console — Reconnect Worker", self.reconnect_console),
            ], spacing=14, expand=True), expand=True, padding=ft.padding.all(20))
        ], spacing=0, expand=True)
        return ft.Container(content=content, expand=True, animate_opacity=300, key="recon_tab")

    def _build_config_tab(self) -> ft.Container:
        def chk(label: str, key: str, color: str = C_ACCENT) -> ft.Checkbox:
            return ft.Checkbox(label=label, value=self.config.get(key, False), on_change=lambda e: self._update_config(key, e.control.value), active_color=color, label_style=ft.TextStyle(font_family="Rajdhani", size=12, color=C_TEXT_SEC))
        ntfy_input = make_input("NTFY.SH TOPIC", "Ex: ark-tribe-alerts", value=self.config.get("ntfy_topic", ""), on_change=lambda e: self._update_config("ntfy_topic", e.control.value))
        kw_input = make_input("CUSTOM KEYWORDS", "Ex: SKY, RAID, C4", value=self.config.get("custom_keywords", ""), on_change=lambda e: self._update_config("custom_keywords", e.control.value))
        content = ft.Column([
            self._make_tab_header("Settings", "Global system adjustments"),
            ft.Container(content=ft.ListView([
                make_card(make_section_label("NTFY.SH NOTIFICATIONS", C_ACCENT), ntfy_input, ft.Text("Events with @everyone → MAX priority", font_family="JetBrainsMono", size=9, color=C_TEXT_MUTED)),
                make_card(make_section_label("SMART LOG MONITORING", "#55efc4"),
                         chk("Anti-Raid Monitoring - @everyone on structure destruction", "anti_raid_enabled", "#55efc4"),
                         chk("Anti-Inside Security - @everyone on TP Public/Admin", "anti_inside_enabled", "#55efc4"),
                         chk("Cloud Watch - @everyone on uploaded dinos", "private_lines_enabled", "#55efc4")),
                make_card(make_section_label("CUSTOM KEYWORDS", "#74b9ff"), kw_input, ft.Text("If found in log → @everyone alert", font_family="JetBrainsMono", size=9, color=C_TEXT_MUTED)),
                make_btn_primary("SAVE CONFIGURATION", "💾", on_click=self._save_config_click),
            ], spacing=12, expand=True), expand=True, padding=ft.padding.all(20))
        ], spacing=0, expand=True)
        return ft.Container(content=content, expand=True, animate_opacity=300, key="config_tab")

    def _build_history_tab(self) -> ft.Container:
        from engine.local_event_logger import LocalEventLogger
        self._hist_logger = LocalEventLogger()
        date_combo = ft.Dropdown(label="DATE", options=[ft.dropdown.Option("All")], value="All", bgcolor=C_BG_INPUT, border_color=C_BORDER, width=180, text_style=ft.TextStyle(size=11))
        type_combo = ft.Dropdown(label="TYPE", options=[ft.dropdown.Option("All")], value="All", bgcolor=C_BG_INPUT, border_color=C_BORDER, width=150, text_style=ft.TextStyle(size=11))
        self._hist_info = ft.Text("Select date and filter events.", size=10, color=C_TEXT_MUTED)
        self._hist_table = ft.DataTable(columns=[ft.DataColumn(ft.Text("Date")), ft.DataColumn(ft.Text("Time")), ft.DataColumn(ft.Text("Type")), ft.DataColumn(ft.Text("Text")), ft.DataColumn(ft.Text("Photo"))], rows=[], heading_row_color=f"{C_ACCENT}0d", data_row_color={"hovered": f"{C_ACCENT}0a"}, border=ft.border.all(1, C_BORDER), border_radius=8)
        
        def refresh_dates(_=None):
            dates = self._hist_logger.list_available_files()
            date_combo.options = [ft.dropdown.Option("All")] + [ft.dropdown.Option(d) for d in dates]
            try: date_combo.update()
            except: pass

        def do_filter(_=None):
            date_sel = date_combo.value or "All"
            events = self._hist_logger.read_events(date_str=None if date_sel == "All" else date_sel)
            self._hist_table.rows.clear()
            for ev in events:
                ts = ev.get("ts", "")
                self._hist_table.rows.append(ft.DataRow(cells=[
                    ft.DataCell(ft.Text(ts[:10])), ft.DataCell(ft.Text(ts[11:19])),
                    ft.DataCell(ft.Container(content=ft.Text(ev.get("type", "").upper(), size=10, color=C_ACCENT), bgcolor=f"{C_ACCENT}1a", padding=4, border_radius=4)),
                    ft.DataCell(ft.Text(ev.get("text", "")[:60])),
                    ft.DataCell(ft.IconButton(icon=ft.icons.IMAGE_SEARCH, icon_color=C_ACCENT, on_click=lambda _, e=ev: self._open_event_photo(e)))
                ], on_select_changed=lambda e, ev=ev: self._on_row_interact(e, ev)))
            self._hist_info.value = f"Showing {len(events)} event(s)."
            try: self._hist_info.update(); self._hist_table.update()
            except: pass

        refresh_dates(); do_filter()
        content = ft.Column([
            self._make_tab_header("History", "Locally saved events"),
            ft.Container(content=ft.Column([
                make_card(make_section_label("FILTERS"), ft.Row([date_combo, type_combo, make_btn_ghost("🔄", on_click=refresh_dates), make_btn_primary("FILTER", "🔍", on_click=do_filter)], spacing=10), self._hist_info),
                ft.Container(content=ft.Column([self._hist_table], scroll=ft.ScrollMode.AUTO), expand=True),
            ], spacing=14, expand=True), expand=True, padding=ft.padding.all(20))
        ], spacing=0, expand=True)
        return ft.Container(content=content, expand=True, animate_opacity=300, key="hist_tab")

    def _toggle_log(self, btn):
        if not self.log_worker:
            if not self.log_region:
                self._add_to_console(self.log_console, "❌ Please select LOG region first.")
                return
            self.log_worker = LogWorker(signals=self.signals, webhook_url=self.config.get("log_webhook", ""), log_region=self.log_region, config_manager=self.config_manager, initial_history=set(self.config.get("log_history", [])))
            self.log_worker.start()
            self._add_to_console(self.log_console, "✅ Log Monitor started.")
            self._status_pills["log"].set_active(True); self._set_online(True); self._log_btn_text.value = "STOP LOG"
        else:
            self.log_worker.stop(); self.log_worker = None
            self._add_to_console(self.log_console, "⏹ Log Monitor stopped.")
            self._status_pills["log"].set_active(False); self._log_btn_text.value = "START LOG"
        try: btn.update()
        except: pass


    def _toggle_disconnect(self, btn):
        if not self.disconnect_worker:
            self.disconnect_worker = DisconnectWorker(signals=self.signals, config_manager=self.config_manager, region=self.disc_region)
            self.disconnect_worker.start()
            self._add_to_console(self.reconnect_console, "✅ Disconnect Monitor started.")
            self._status_pills["disc"].set_active(True); self._disc_btn_text.value = "STOP WATCHER"
        else:
            self.disconnect_worker.stop(); self.disconnect_worker = None
            self._add_to_console(self.reconnect_console, "⏹ Disconnect Monitor stopped.")
            self._status_pills["disc"].set_active(False); self._disc_btn_text.value = "START WATCHER"
        try: btn.update()
        except: pass

    def _toggle_reconnect(self, e):
        self._add_to_console(self.reconnect_console, "ℹ️ Watcher is always active monitoring for disconnections.")

    def _select_zone(self, zone_type: str):
        console = self.log_console
        self._add_to_console(console, f"📐 Opening region selector ({zone_type.upper()})...")
        snipper_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ui", "widgets", "snipping_tool.py")
        def _run():
            try:
                proc = subprocess.Popen([sys.executable, "-u", snipper_path, "cyan"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                stdout, _ = proc.communicate()
                if stdout.strip():
                    try:
                        region = json.loads(stdout.strip().splitlines()[-1])
                        self._add_to_console(console, f"✅ Region captured: {region}")
                        self._save_zone(zone_type, region)
                    except: self._add_to_console(console, "❌ Invalid response format.")
                else: self._add_to_console(console, "ℹ️ Selection cancelled.")
            except Exception as ex: self._add_to_console(console, f"❌ Selector error: {str(ex)[:50]}")
        threading.Thread(target=_run, daemon=True).start()

    def _save_zone(self, zone_type: str, region: list):
        key = {"log": "log_region", "join": "join_region", "disc": "disconnect_region"}.get(zone_type)
        if not key: return
        self._update_config(key, region)
        reg = tuple(region)
        if zone_type == "log": self.log_region = reg; tag = self._log_zone_row
        elif zone_type == "disc": self.disc_region = reg; tag = self._disc_zone_row
        else: return
        try:
            txt = tag.content.controls[1]; txt.value = str(reg); txt.color = C_ACCENT; self._safe_update(tag)
        except: pass

    def _start_calibration(self, e):
        async def _calib_task():
            import pyautogui
            for i in range(5, 0, -1):
                self._add_to_console(self.reconnect_console, f"🎯 [CALIB] Place mouse over button... {i}s")
                self.calib_tag_ref.value = f"⏳ Capturing in {i}s..."; self.page.update(); await asyncio.sleep(1)
            pos = pyautogui.position(); self.reconnect_pos = (pos.x, pos.y); self._update_config("reconnect_pos", [pos.x, pos.y])
            self._add_to_console(self.reconnect_console, f"✅ [CALIB] Captured: {self.reconnect_pos}")
            self.calib_tag_ref.value = f"📍 Calibrated: {self.reconnect_pos}"; self.calib_tag_ref.color = C_GREEN; self.page.update()
        self.page.run_task(_calib_task)

    def _update_config(self, key: str, value):
        self.config[key] = value; self.config_manager.save()

    def _save_config_click(self, e):
        self.config_manager.save(); self._add_to_console(self.log_console, "💾 Configuration saved.")

    def _on_row_interact(self, e, ev):
        if e.data == "true": # Double click simulation / Selection
            self._open_event_photo(ev)

    def _open_event_photo(self, ev):
        from engine.local_event_logger import LocalEventLogger
        logger = LocalEventLogger()
        path = logger.find_event_photo(ev)
        if path and os.path.exists(path):
            self._add_to_console(self.log_console, f"🖼 Opening photo: {os.path.basename(path)}")
            os.startfile(path)
        else: self._add_to_console(self.log_console, "⚠️ Photo not found for this event.")

    def on_close(self):
        for w in [self.log_worker, self.disconnect_worker, self.reconnect_worker]:
            if w:
                try: w.stop()
                except: pass
        bus.clear()

async def _show_loading(page: ft.Page):
    page.bgcolor = C_BG_BASE; page.vertical_alignment = ft.MainAxisAlignment.CENTER; page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    spinner = ft.ProgressRing(width=72, height=72, stroke_width=3, color=C_ACCENT, bgcolor=f"{C_ACCENT}15")
    logo = ft.Column([ft.Text("LOG", size=14, weight="bold", color=C_ACCENT), ft.Text("BOT", size=9, color=C_TEXT_MUTED)], alignment="center", horizontal_alignment="center", spacing=0)
    loader = ft.Stack([ft.Container(spinner, width=72, height=72), ft.Container(logo, width=72, height=72, alignment=ft.alignment.center)])
    step_text = ft.Text("Initializing...", size=16, color=C_ACCENT)
    switcher = ft.AnimatedSwitcher(step_text, duration=400)
    progress = ft.ProgressBar(width=280, value=0, color=C_ACCENT)
    page.add(ft.Column([loader, ft.Container(height=40), switcher, ft.Container(height=16), progress], horizontal_alignment="center", alignment="center"))
    page.update()
    STEPS = [("Preparing Environment...", 0.2), ("Loading Config...", 0.4), ("Starting Workers...", 0.7), ("Ready!", 1.0)]
    for text, pct in STEPS:
        switcher.content = ft.Text(text, size=16, color=C_ACCENT); progress.value = pct; page.update(); await asyncio.sleep(0.5)

async def create_app(page: ft.Page):
    page.title = "LogBot v8.5 PRO"; page.theme_mode = ft.ThemeMode.DARK; page.bgcolor = C_BG_BASE
    page.window_min_width = 900; page.window_min_height = 640; page.padding = 0
    await _show_loading(page); page.clean()
    app = ArkLogApp(page)
    page.on_disconnect = lambda _: app.on_close()
    page.add(app.build()); page.update()