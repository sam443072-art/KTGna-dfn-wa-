"""
ui/widgets/snipping_tool.py - Selector de zona por captura congelada.
"""

import sys
import json
import os
import pygame
import win32api
import win32con
import pyautogui

def main():
    color_name = sys.argv[1] if len(sys.argv) > 1 else "cyan"
    colors = {"cyan": (0, 229, 255), "green": (0, 255, 136), "orange": (255, 107, 53)}
    draw_color = colors.get(color_name, (0, 255, 136))

    # 1. Capturar la pantalla antes de abrir nada
    screenshot = pyautogui.screenshot()
    
    pygame.init()
    
    # Dimensiones
    w = win32api.GetSystemMetrics(win32con.SM_CXVIRTUALSCREEN)
    h = win32api.GetSystemMetrics(win32con.SM_CYVIRTUALSCREEN)
    x_off = win32api.GetSystemMetrics(win32con.SM_XVIRTUALSCREEN)
    y_off = win32api.GetSystemMetrics(win32con.SM_YVIRTUALSCREEN)

    # Convertir captura a imagen de PyGame
    bg_image = pygame.image.fromstring(screenshot.tobytes(), screenshot.size, screenshot.mode)
    bg_image = pygame.transform.scale(bg_image, (w, h))

    # Create borderless fullscreen window
    screen = pygame.display.set_mode((w, h), pygame.NOFRAME)
    pygame.display.set_caption("Region Selector")
    
    # Puntero tipo cruz
    pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_CROSSHAIR)

    running = True
    start_pos = None

    while running:
        # Dibujar la captura de pantalla de fondo
        screen.blit(bg_image, (0, 0))
        
        # Capa oscura para resaltar la selección
        dark_overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        dark_overlay.fill((0, 0, 0, 100)) # Sombra oscura
        screen.blit(dark_overlay, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                print(json.dumps([]))
                running = False
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                start_pos = pygame.mouse.get_pos()
                
            elif event.type == pygame.MOUSEBUTTONUP:
                if start_pos:
                    end_pos = pygame.mouse.get_pos()
                    x1, y1 = min(start_pos[0], end_pos[0]), min(start_pos[1], end_pos[1])
                    x2, y2 = max(start_pos[0], end_pos[0]), max(start_pos[1], end_pos[1])
                    width, height = x2 - x1, y2 - y1
                    
                    if width > 5 and height > 5:
                        # Resultado real compensado
                        print(json.dumps([x1 + x_off, y1 + y_off, width, height]))
                        running = False
                    start_pos = None

        if start_pos:
            curr = pygame.mouse.get_pos()
            rect = pygame.Rect(min(start_pos[0], curr[0]), min(start_pos[1], curr[1]),
                               abs(start_pos[0] - curr[0]), abs(start_pos[1] - curr[1]))
            
            # Dibujar el área seleccionada "limpia" (sin sombra)
            screen.blit(bg_image, rect, rect)
            # Borde del rectángulo
            pygame.draw.rect(screen, draw_color, rect, 2)

        pygame.display.flip()
        pygame.time.delay(10)

    pygame.quit()

if __name__ == "__main__":
    main()
