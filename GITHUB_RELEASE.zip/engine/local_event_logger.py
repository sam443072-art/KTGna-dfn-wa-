"""
engine/local_event_logger.py - Gestión de persistencia local de eventos.
Guarda los eventos en formato JSON divididos por fecha.
"""

import os
import json
import glob
import threading
from datetime import datetime
from PIL import Image
from typing import Optional, List, Dict

class LocalEventLogger:
    """Implementa el sistema de guardado local de eventos del monitor."""
    
    _lock = threading.RLock() # Lock a nivel de clase para seguridad total entre workers
    
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = os.path.join(os.getcwd(), logs_dir)
        if not os.path.exists(self.logs_dir):
            os.makedirs(self.logs_dir)
        
        # Subdirectorio de imágenes
        self.img_dir = os.path.join(self.logs_dir, "images")
        if not os.path.exists(self.img_dir):
            os.makedirs(self.img_dir)
            
    def save_event(self, 
                   event_type: str, 
                   text: str, 
                   image: Optional[Image.Image] = None, 
                   save_image: bool = True):
        """
        Guarda un evento en el archivo JSON del día actual con filtro de duplicados.
        """
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        ts_str = now.strftime("%Y-%m-%d %H:%M:%S")
        
        log_file = os.path.join(self.logs_dir, f"events_{date_str}.json")
        
        # Leer datos bajo el Lock para evitar corrupción
        with self._lock:
            # 1. Leer datos existentes para filtrar duplicados
            data = []
            if os.path.exists(log_file):
                try:
                    with open(log_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except: data = []
            
            # 2. FILTRO ANTI-DUPLICADOS (Últimos 15 segundos)
            if data:
                for existing in data[-15:]:
                    if existing.get("text") == text:
                        try:
                            prev_time = datetime.strptime(existing.get("ts"), "%Y-%m-%d %H:%M:%S")
                            if (now - prev_time).total_seconds() < 15:
                                return # Ignorar
                        except: pass

            img_name = None
            if image and save_image:
                img_id = f"{now.strftime('%H%M%S')}_{event_type[:6]}"
                img_name = f"{img_id}.png"
                img_path = os.path.join(self.img_dir, img_name)
                try: image.save(img_path)
                except Exception as e: print(f"[LOGGER ERROR] Save image: {e}")
            
            # 4. Preparar data entry y persistir
            entry = {"ts": ts_str, "type": event_type, "text": text, "image": img_name}
            data.append(entry)
            try:
                with open(log_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)
            except Exception as e: print(f"[LOGGER ERROR] Persist JSON: {e}")

    def find_event_photo(self, event_entry: Dict) -> Optional[str]:
        """Busca la ruta física de la foto asociada a un evento."""
        image_name = event_entry.get("image")
        if not image_name:
            return None
            
        path = os.path.join(self.img_dir, image_name)
        if os.path.exists(path):
            return path
        return None

    def list_available_files(self) -> List[str]:
        """Retorna lista de fechas que tienen logs (formato YYYY-MM-DD)."""
        import glob
        files = glob.glob(os.path.join(self.logs_dir, "events_*.json"))
        # Extraer fechas del nombre 'events_2023-10-10.json'
        dates = [os.path.basename(f).replace("events_", "").replace(".json", "") for f in files]
        return sorted(dates, reverse=True)

    def read_events(self, date_str: Optional[str] = None) -> List[Dict]:
        """Lee eventos bajo el lock para consistencia."""
        with self._lock:
            if date_str:
                log_file = os.path.join(self.logs_dir, f"events_{date_str}.json")
                if os.path.exists(log_file):
                    try:
                        with open(log_file, "r", encoding="utf-8") as f:
                            return json.load(f)
                    except: return []
                return []
            else:
                all_events = []
                files = glob.glob(os.path.join(self.logs_dir, "events_*.json"))
                files.sort(reverse=True)
                for f_path in files[:5]: # últimos 5 días
                    try:
                        with open(f_path, "r", encoding="utf-8") as f:
                            all_events.extend(json.load(f))
                    except: pass
                return all_events
