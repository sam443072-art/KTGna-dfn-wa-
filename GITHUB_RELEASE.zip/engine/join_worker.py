"""
JoinWorker: Monitor de nuevas uniones a la tribu.
Detecta cuando alguien se une y envía notificación a Discord.
"""

import threading
import time
from typing import Tuple, Set
from PIL import Image
import pyautogui
from collections import deque

from engine.signals import BotSignals
from core.vision import DialogVisionEngine
from core.capture import WindowCapture
from utils.webhook_sender import WebhookSender
from utils.ntfy_notifier import NtfyNotifier
from config.config_manager import ConfigManager


class JoinWorker(threading.Thread):
    """
    Monitor para detectar uniones de nuevos miembros a la tribu.
    Se dispara cuando detecta un mensaje de unión en el chat/log.
    """
    
    def __init__(self,
                 signals: BotSignals,
                 webhook_url: str,
                 join_region: Tuple[int, int, int, int],
                 config_manager: ConfigManager):
        """
        Inicializa JoinWorker.
        
        Args:
            signals: BotSignals para comunicación
            webhook_url: URL del webhook de Discord
            join_region: Tupla (x, y, w, h) de la región donde se ve uniones
            config_manager: Instancia de ConfigManager
        """
        super().__init__(daemon=True)
        
        self.signals = signals
        self.webhook_url = webhook_url
        self.join_region = join_region
        self.config_manager = config_manager
        self._is_running = True
        self.check_interval = 5
        
        # Para evitar spam (Usamos deque maxlen para rotación automática - Punto #6)
        self.last_reads = deque(maxlen=100)
        
        self.vision_engine = DialogVisionEngine()  # ← Especializado para diálogos
    
    def stop(self) -> None:
        """Detiene el worker."""
        self._is_running = False
    
    def log(self, msg: str) -> None:
        """Emite mensaje a consola GUI."""
        self.signals.console_msg.emit(msg)
    
    def update_region(self, new_region: Tuple[int, int, int, int]) -> None:
        """Actualiza región de captura."""
        self.join_region = new_region
    
    def run(self) -> None:
        """Main thread."""
        self.log("🚪 [JOIN] Join Monitor Started.")
        
        while self._is_running:
            try:
                self._process_screen()
            except Exception as e:
                self.log(f"⚠️ [JOIN ERROR] {str(e)[:100]}")
            
            time.sleep(self.check_interval)
    
    def _process_screen(self) -> None:
        """Captura y procesa la región de uniones."""
        x, y, w, h = self.join_region
        
        # Capturar región
        pil_image = WindowCapture.get_screenshot_with_fallback(
            "ArkAscended",
            region=(x, y, w, h)
        )
        
        if not pil_image:
            return
        
        # Preprocesar agresivamente usando DialogVisionEngine
        try:
            text = self.vision_engine.read(pil_image)
        except Exception as e:
            self.log(f"⚠️ [JOIN OCR] {str(e)[:50]}")
            return
        
        if not text.strip():
            return
        
        # Detectar palabras clave de unión (Typo corregido - Punto #6)
        keywords = ["joined", "unido", "join", "tribe member", "tribemember"]
        found = False
        text_low = text.lower()
        
        for keyword in keywords:
            if keyword in text_low:
                found = True
                break
        
        if found and text not in self.last_reads:
            self.last_reads.append(text)
            self.log(f"🚪 [JOIN] New member detected: {text[:40]}...")
            self._send_to_discord(text, pil_image)
    
    def _send_to_discord(self, text: str, pil_image: Image.Image) -> None:
        """Envía notificación de unión a Discord."""
        if not self.webhook_url:
            return
        
        config = self.config_manager.get_all()
        
        msg = f"🚪 **New Tribe Member Joined**\n{text}"
        
        sent = False
        if config.get("log_send_photo", True):
            sent = WebhookSender.send_with_image(
                self.webhook_url,
                msg,
                pil_image,
                "join.png"
            )
        else:
            sent = WebhookSender.send_text(self.webhook_url, msg)
        
        if sent:
            self.log("✅ [DISCORD] Join message sent")
            
            # Notificación remota
            topic = config.get("ntfy_topic", "")
            if topic:
                try:
                    NtfyNotifier.send_success(
                        topic,
                        text[:100],
                        title="🚪 New Member"
                    )
                except Exception as e:
                    self.log(f"⚠️ Error en ntfy (join): {str(e)[:50]}")
        else:
            self.log("⚠️ [DISCORD] Error sending join notification")
