"""
DisconnectWorker: Monitor de desconexión visual inteligente.
Versión corregida: Búsqueda flexible de palabras y loop persistente.
"""

import threading
import time
import re
import unicodedata
import win32gui
import win32api
import win32con
import pyautogui
import pytesseract
from typing import Tuple, Optional, Dict, List
from PIL import Image

from engine.signals import BotSignals
from core.vision import DialogVisionEngine
from core.capture import WindowCapture
from config.config_manager import ConfigManager
from engine.local_event_logger import LocalEventLogger


class DisconnectWorker(threading.Thread):
    def __init__(self,
                 signals: BotSignals,
                 config_manager: ConfigManager,
                 region: Optional[Tuple[int, int, int, int]] = None):
        super().__init__(daemon=True)
        
        self.signals = signals
        self.config_manager = config_manager
        self.region = region
        self._is_running = True
        self.scan_interval = 4
        
        self.vision_engine = DialogVisionEngine()
        
        # Coordenadas calibradas (Caché desde config)
        self.calibrated_pos = self.config_manager.get("reconnect_pos")
        if self.calibrated_pos:
             self.calibrated_pos = tuple(self.calibrated_pos)
        
        self.event_logger = LocalEventLogger()
        
        # Keywords Flexibles
        self.K_LOST = ["conexionperdida", "conexion", "perdida", "lostconnection", "lost", "timeout", "host"]
        self.K_SESSION = ["unete", "ultima", "sesion", "session", "uneteala"]
        self.K_ACCEPT = ["aceptar", "accept", "ok"]

    def stop(self) -> None:
        self._is_running = False
    
    def log(self, msg: str) -> None:
        self.signals.console_msg.emit(f"[RECO] {msg}")

    def update_region(self, region: Optional[Tuple[int, int, int, int]]) -> None:
        self.region = region
        self.log(f"📐 Region updated: {region}")
    
    def update_calibrated_pos(self, pos: Tuple[int, int]) -> None:
        self.calibrated_pos = pos
        self.log(f"📍 Calibrated position updated: {pos}")

    def _get_center_region(self) -> Tuple[int, int, int, int]:
        sw, sh = pyautogui.size()
        width = int(sw * 0.45); height = int(sh * 0.45)
        return ((sw - width) // 2, (sh - height) // 2, width, height)

    def _normalize(self, text: str) -> str:
        """Normalización que ELIMINA espacios para comparaciones brutas."""
        text = unicodedata.normalize("NFD", text)
        text = "".join(c for c in text if unicodedata.category(c) != "Mn")
        clean = re.sub(r"[^a-z0-9]", "", text.lower()).strip()
        return clean

    def _ocr_region(self, region: Tuple[int, int, int, int]) -> str:
        pil_img = WindowCapture.get_screenshot_with_fallback("ArkAscended", region=region)
        if not pil_img: return ""
        
        # Usamos el filtro nítido pero también OCR crudo como fallback rápido
        text = self.vision_engine.read(pil_img)
        if len(text.strip()) < 3:
            text = pytesseract.image_to_string(pil_img, config="--psm 6")
            
        return self._normalize(text)

    def _smart_click(self, target_keywords: List[str], region: Tuple[int, int, int, int]) -> bool:
        """Busca y hace click. Si falla en localizar exacto, clica el centro."""
        hwnd = WindowCapture.find_window_handle("ArkAscended")
        if not hwnd: return False

        pil_img = WindowCapture.get_screenshot_with_fallback("ArkAscended", region=region)
        if not pil_img: return False
        
        data = self.vision_engine.read_with_positions(pil_img)
        # Buscar en el texto completo normalizado (unido)
        full_text_joined = "".join([self._normalize(w) for w in data['text']])
        
        for kw in target_keywords:
            if kw in full_text_joined:
                self.log(f"🎯 Detected '{kw}' on screen. Proceeding to click...")
                
                # Intentar localizar caja de colisión del texto
                for i, word_text in enumerate(data['text']):
                    w_norm = self._normalize(word_text)
                    if w_norm in kw or kw in w_norm:
                        rx = data['left'][i] + (data['width'][i] // 2)
                        ry = data['top'][i] + (data['height'][i] // 2)
                        
                        gx = region[0] + rx
                        gy = region[1] + ry
                        
                        self._perform_click(hwnd, gx, gy)
                        return True
                
                # Fallback: Click central if box not found
                self.log("⚠️ Could not detect exact button box. Using central security click.")
                self._perform_click(hwnd, region[0] + region[2]//2, region[1] + region[3]//2)
                return True
        return False

    def _perform_click(self, hwnd, gx, gy):
        """Ejecuta un clic instantáneo sin dependencias lentas."""
        try:
            # 1. Fuerza el foco de forma nativa (Bypass de Windows)
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32gui.BringWindowToTop(hwnd)
            try: win32gui.SetForegroundWindow(hwnd)
            except: pass # Si Windows lo bloquea, seguimos con el click igual

            # 2. Click Físico Rápido
            pyautogui.click(int(gx), int(gy))
            
            # 3. Click de Respaldo por Software (Doble Seguridad)
            win_l, win_t, _, _ = win32gui.GetWindowRect(hwnd)
            lx, ly = int(gx - win_l), int(gy - win_t)
            lParam = win32api.MAKELONG(lx, ly)
            win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lParam)
            win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lParam)
            
            self.log(f"🖱️ Physical and digital click completed at ({gx}, {gy})")
            return True
        except Exception as e:
            self.log(f"⚠️ Error click: {e}")
            return False

    def run(self) -> None:
        self.log("🔌 [RECO] Reconnection monitor started (Persistent Mode).")
        
        while self._is_running:
            try:
                mon_region = self.region if self.region else self._get_center_region()
                
                # Capturar imagen una sola vez por ciclo
                pil_img = WindowCapture.get_screenshot_with_fallback("ArkAscended", region=mon_region)
                if not pil_img:
                    time.sleep(self.scan_interval)
                    continue

                # Procesar OCR sobre la imagen ya capturada
                text_raw = self.vision_engine.read(pil_img)
                if len(text_raw.strip()) < 3:
                    text_raw = pytesseract.image_to_string(pil_img, config="--psm 6")
                text_joined = self._normalize(text_raw)
                
                # Búsqueda booleana
                is_lost = any(kw in text_joined for kw in self.K_LOST)
                is_session = any(kw in text_joined for kw in self.K_SESSION)

                if is_lost:
                    self.log("🔴 [DETECT] DISCONNECTION dialog. Clicking ACCEPT...")
                    try:
                        self.event_logger.save_event("disc", "DISCONNECTION DIALOG DETECTED - Clicking Accept", image=pil_img, save_image=True)
                    except: pass
                    
                    if self._smart_click(self.K_ACCEPT, mon_region):
                        time.sleep(2.0)
                
                elif is_session:
                    self.log("🟡 [DETECT] JOIN SESSION button. Clicking...")
                    try:
                        self.event_logger.save_event("reco", "JOIN SESSION DETECTED - Initiating Reconnection", image=pil_img, save_image=True)
                    except: pass
                    # ... (rest of the logic)
                    
                    if self.calibrated_pos:
                        gx, gy = self.calibrated_pos
                        hwnd = WindowCapture.find_window_handle("ArkAscended")
                        if hwnd and self._perform_click(hwnd, gx, gy):
                            self.signals.auto_reconnect.emit()
                            self.log("✅ [GPS] Click at CALIBRATED position successful.")
                            time.sleep(15)
                    elif self._smart_click(self.K_SESSION, mon_region):
                        self.signals.auto_reconnect.emit()
                        self.log("✅ Reconnection sent (OCR). Entering 15s cooldown...")
                        time.sleep(15)
                
                # Importante: No bloqueamos con 'time.sleep' largo fuera de aquí
                # El loop debe seguir vivo
                time.sleep(self.scan_interval)
                
            except Exception as e:
                self.log(f"⚠️ [RECO ERROR] {str(e)[:60]}")
                time.sleep(self.scan_interval)
