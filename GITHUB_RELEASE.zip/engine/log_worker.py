"""
LogWorker: Motor de monitoreo de logs de tribu.
Responsabilidad: Capturar región LOG → OCR → Detectar eventos → Enviar a Discord.
"""

import threading
import time
import re
import hashlib
from datetime import datetime
from typing import Dict, List, Set, Optional, Tuple
from PIL import Image

# Importaciones internas
from engine.signals import BotSignals
from core.vision import LogVisionEngine
from core.capture import WindowCapture
from utils.webhook_sender import WebhookSender
from utils.ntfy_notifier import NtfyNotifier
from utils.audio_player import AudioPlayer
from utils.event_logger import EventLogger
from config.config_manager import ConfigManager


class LogWorker(threading.Thread):
    """
    Worker que monitorea el log de tribu con deduplicación inteligente y caché de config.
    """
    
    def __init__(self, 
                 signals: BotSignals, 
                 webhook_url: str,
                 log_region: Tuple[int, int, int, int],
                 config_manager: ConfigManager,
                 initial_history: Optional[Set[str]] = None):
        super().__init__(daemon=True)
        
        self.signals = signals
        self.webhook_url = webhook_url
        self.log_region = log_region
        self.config_manager = config_manager
        
        self._is_running = True
        # Usamos el Día y Hora como ID único para evitar repetidos
        self.processed_events: Set[str] = initial_history or set()
        
        self.vision_engine = LogVisionEngine()  # ← Especializado para logs
        self.event_logger = EventLogger()
        
        self.stats = {"total_events": 0, "last_event_time": None}
        self.no_new_data_scans = 0
    
    def stop(self) -> None:
        self._is_running = False
    
    def log(self, msg: str) -> None:
        """Emite mensaje firmado para ruteo a consola de Log."""
        self.signals.console_msg.emit(f"[LOG] {msg}")
    
    def update_region(self, new_region: Tuple[int, int, int, int]) -> None:
        self.log_region = new_region
        self.log(f"📐 [LOG] Region updated: {new_region}")
    
    def run(self) -> None:
        self.log("[LOG] ✅ Tribe Log Monitor Started.")
        
        while self._is_running:
            try:
                # Cache config at cycle start
                config = self.config_manager.get_all()
                self._process_screen(config)
            except Exception as e:
                self.log(f"[LOG ERROR] {str(e)[:100]}")
            
            time.sleep(4)
        
        self.log("[LOG] ⏹ Monitor stopped.")
    
    def _process_screen(self, config: dict) -> None:
        x, y, w, h = self.log_region
        
        # Validar que la región sea válida
        if not all([x >= 0, y >= 0, w > 0, h > 0]):
            self.log(f"❌ [ERROR] Invalid capture region: ({x}, {y}, {w}, {h})")
            return
        
        pil_image = WindowCapture.get_screenshot_with_fallback(
            "ArkAscended", 
            region=(x, y, w, h)
        )
        
        if not pil_image:
            self.log("⚠️ [CAPTURE] Could not capture region (window minimized or not found)")
            return
        
        try:
            raw_text = self.vision_engine.read(pil_image)  # Usando método de LogVisionEngine
        except Exception as e:
            self.log(f"❌ [OCR ERROR] {str(e)[:80]} (región={self.log_region})")
            return
        
        raw_lines = [line.strip() for line in raw_text.split('\n') if len(line.strip()) > 3]
        if not raw_lines:
            self.no_new_data_scans += 1
            return
        
        events_reconstructed = self._reconstruct_events(raw_lines)
        
        # El nuevo motor procesa, filtra y envía todo en un solo flujo
        config = self.config_manager.data
        self._process_new_entries(events_reconstructed, pil_image, config)
    
    def _reconstruct_events(self, raw_lines: List[str]) -> List[str]:
        events = []
        temp_line = ""
        for line in raw_lines:
            if re.search(r"Day \d+, \d{2}:\d{2}:\d{2}", line):
                if temp_line: events.append(temp_line)
                temp_line = line
            else:
                if temp_line: temp_line += " " + line
        if temp_line: events.append(temp_line)
        return events
    
    def _process_new_entries(self, current_entries: list, pil_image: Image.Image, config: dict): # Added config parameter
        """Procesa entradas usando el Día y Hora como clave única anti-spam."""
        new_valid_entries = []
        
        # Regex para extraer el sello de tiempo (Day XXX, HH:MM:SS)
        # re is already imported at the top, no need for local import
        ts_regex = re.compile(r"Day\s*\d+,\s*\d{2}:\d{2}:\d{2}")

        for entry in current_entries:
            if len(entry.strip()) < 10: continue
            
            # 1. Intentar capturar el Día y Hora como ID único
            match = ts_regex.search(entry)
            if match:
                entry_id = match.group(0) # Clave: "Day 13349, 22:32:15"
            else:
                # Fallback: Usar los últimos 20 caracteres si no hay fecha clara
                entry_id = entry[-20:]
            
            # 2. Verificar si ya lo procesamos hoy
            if entry_id not in self.processed_events:
                self.processed_events.add(entry_id)
                new_valid_entries.append(entry)
                
                # Mantener el set limpio (máximo 500 IDs para no saturar memoria)
                if len(self.processed_events) > 500:
                    # Convertir a lista y quitar los más antiguos
                    old_list = list(self.processed_events)
                    self.processed_events = set(old_list[100:])

        if new_valid_entries:
            self.no_new_data_scans = 0
            self.log(f"📝 {len(new_valid_entries)} new entries detected.")
            
            filtered_entries = self._apply_filters(new_valid_entries, config)
            self.log(f"🔍 {len(filtered_entries)} entries passed filters.")
            
            if filtered_entries:
                self.log("📡 Sending report to Discord...")
                self._send_to_discord(filtered_entries, pil_image, config)
                self._save_locally(filtered_entries, pil_image, config)
            else:
                self.log("ℹ️ No important entries to send after filtering.")
                # The original _process_new_entries snippet had these calls directly,
                # but the existing structure uses _send_to_discord, _save_locally, _play_alarm, _send_ntfy_notification
                # which are called after filtering.
                # I'm adapting to the existing flow by calling _apply_filters first.
                # The original snippet's calls:
                # self._save_locally(new_valid_entries, pil_image)
                # self._send_discord_webhook(new_valid_entries, pil_image)
                # self._send_ntfy_notification(new_valid_entries)
                # self._play_alarm(new_valid_entries)
                # These are now handled by _send_to_discord and _save_locally after filtering.
                # _play_alarm and _send_ntfy_notification are called within _send_to_discord.
        else:
            self.no_new_data_scans += 1 # Increment if no new entries
    
    def _apply_filters(self, entries: List[str], config: dict) -> List[str]:
        filtered = []
        # COMENTADO TEMPORALMENTE: Enviamos todo a Discord por petición del usuario
        # topic_events = config.get("topic_events", [])
        
        for line in entries:
            line_low = line.lower()
            # event_type = self._detect_event_type(line_low)
            
            # Solo filtramos si hay temas específicos seleccionados
            # if topic_events and event_type:
            #     if event_type not in topic_events:
            #         self.log(f"🕵️ Filtrado por tema: {event_type}")
            #         continue
            
            # Filtros mejorados para Demolish/Destroyed (Ahorro de spam)
            if config.get("improved_demolish", False) and "demolish" in line_low:
                important = ["generator tek", "tek generator", "heavy turret", "tek turret", "teleport"]
                if not any(k in line_low for k in important): continue
            
            if config.get("improved_destroyed", False) and "destroyed" in line_low:
                trash = ["thatch", "wood", "stone", "wall", "ceiling", "floor", "foundation"]
                important = ["turret", "generator", "teleport"]
                if any(t in line_low for t in trash) and not any(i in line_low for i in important):
                    continue
            
            filtered.append(line)
        return filtered
    
    def _detect_event_type(self, line_low: str) -> Optional[str]:
        """Identifica el tipo de evento para aplicar la plantilla correspondiente."""
        if "was killed by a" in line_low: return "member_killed_by_dino"
        if "was killed!" in line_low:
             if "your tribe" in line_low or "your " in line_low: return "dino_killed"
             return "member_killed"
        if "your tribe killed" in line_low: return "tribe_killed_enemy"
        if "was added to the tribe" in line_low: return "recruit"
        if "set to rank group" in line_low: return "rank_change"
        if "claimed" in line_low: return "claim_baby"
        if "unclaimed" in line_low: return "unclaim"
        if "starved to death" in line_low: return "starve"
        if "froze" in line_low: return "freeze"
        if "demolished" in line_low: return "demolish"
        if "to private" in line_low: return "tp_private"
        if "to public" in line_low: return "tp_public"
        if "was destroyed!" in line_low: return "structure_destroyed"
        if "death essence expired" in line_low: return "essence_expired"
        if "was promoted" in line_low: return "promoted_admin"
        if "uploaded" in line_low: return "uploaded"
        return None

    def _format_with_template(self, entry: str) -> str:
        """Reconstruye la línea del log usando plantillas sin duplicaciones."""
        line_low = entry.lower()
        evt_type = self._detect_event_type(line_low)
        
        # Extraer Día y Hora buscando el último ':' del bloque de tiempo
        ts_match = re.search(r"(Day\s*\d+,\s*\d{2}:\d{2}:\d{2}):\s*", entry)
        if ts_match:
            timestamp = ts_match.group(1)
            content = entry[ts_match.end():].strip() # Cortar exactamente tras el timestamp
        else:
            timestamp = "Day ??, ??:??:??"
            content = entry
        
        # Diccionario de Palabras a Eliminar (para evitar duplicados con la plantilla)
        to_remove = [
            "was killed!", "set to rank group", "was added to the tribe",
            "claimed", "unclaimed", "starved to death", "froze", "demolished",
            "set to private", "set to public", "your tribe killed", "was destroyed!",
            "tribemember ", "your tribe ", "your ", "was killed by a ",
            "was promoted", "uploaded"
        ]

        # Limpiar el contenido de basura del OCR al inicio y fragmentos repetidos
        clean_content = re.sub(r"^[•\s\W]+", "", content)
        for word in to_remove:
            # Reemplazo insensible a mayúsculas
            clean_content = re.sub(word, "", clean_content, flags=re.IGNORECASE).strip()
        
        # Limpiar rastro de basura final tras el '!'
        if "!" in clean_content:
            clean_content = clean_content.split("!", 1)[0].strip()

        # Diccionario de Plantillas Renovado
        templates = {
            "member_killed": "💀 **Tribemember {data} - was killed!**",
            "rank_change": "🔰 **{data} (Rank Change)**",
            "recruit": "🤝 **{data} (New Recruit!)**",
            "claim_baby": "🐣 **{data} (Baby Claimed)**",
            "unclaim": "👋 **{data} (Unclaimed)**",
            "starve": "🦴 **{data} (Starved to death)**",
            "freeze": "🧊 **{data} (Cryopod/Freeze)**",
            "demolish": "🔨 **{data} (Demolished)**",
            "tp_private": "🔒 **{data} (Set to Private)**",
            "tp_public": "🔓 **{data} (Set to Public)**",
            "tribe_killed_enemy": "⚔️ **Your Tribe killed {data}!**",
            "member_killed_by_dino": "🦖 **Tribemember {data} (Killed by Dino)**",
            "dino_killed": "🔴 **Your Dino {data} was killed!**",
            "structure_destroyed": "💥 **Your structure {data} was destroyed!**",
            "essence_expired": "⌛ **Dino Essence {data} (Expired)**",
            "promoted_admin": "⭐ **{data} (Promoted to Admin)**",
            "uploaded": "☁️ **{data} (Uploaded to Cloud)**"
        }

        if evt_type in templates:
            return f"`{timestamp}`: {templates[evt_type].format(data=clean_content)}"
        
        return entry
    
    def _send_to_discord(self, entries: List[str], pil_image: Image.Image, config: dict) -> None:
        if not self.webhook_url or not entries: return
        
        now = datetime.now().strftime("%H:%M:%S")
        everyone_events = config.get("everyone_events", [])
        custom_keywords = [kw.strip().lower() for kw in config.get("custom_keywords", "").split(",") if kw.strip()]
        
        has_everyone = any(any(evt in e.lower() for evt in everyone_events) for e in entries)
        has_keyword = any(any(kw in e.lower() for kw in custom_keywords) for e in entries)
        
        mentions = (" @everyone" if has_everyone else "") + (" @here" if has_keyword else "")
        
        # SMART MENTIONS: Lógica para Anti-Raid, Anti-Inside y Cloud Watch
        smart_everyone = False
        critical_lines = []
        
        for entry in entries:
            low = entry.lower()
            evt = self._detect_event_type(low)
            is_critical = False
            
            # 1. Anti-Raid
            if config.get("anti_raid_enabled") and evt == "structure_destroyed":
                 trash = ["thatch", "wood", "stone", "wall", "ceiling", "floor", "foundation"]
                 if not any(t in low for t in trash): is_critical = True
                 
            # 2. Anti-Inside
            if config.get("anti_inside_enabled") and (evt == "tp_public" or evt == "promoted_admin"):
                 is_critical = True
                 
            # 3. Cloud Watch
            if config.get("private_lines_enabled") and evt == "uploaded":
                 is_critical = True
            
            # 4. Keywords
            if has_everyone or has_keyword:
                 keywords = self.config_manager.get_config("custom_keywords", "").split(",")
                 if any(k.strip().lower() in low for k in keywords if k.strip()):
                      is_critical = True

            if is_critical:
                smart_everyone = True
                critical_lines.append(entry)

        if smart_everyone and "@everyone" not in mentions:
            mentions += " @everyone"

        # Aplicar plantillas y DESTACAR si es crítico
        formatted_entries = []
        for e in entries:
            fmt = self._format_with_template(e)
            if e in critical_lines:
                fmt = f"🚨 **CRITICAL: {fmt}** 🚨"  # Destacado visual
            formatted_entries.append(fmt)

        # 5. Obtener población si es crítico
        pop_str = ""
        server_num = config.get("server_number", "")
        if (smart_everyone or has_everyone) and server_num:
            try:
                from utils.ark_api import ArkAPI
                pop_val = ArkAPI.get_server_stats(server_num)
                pop_str = f"👥 **Online Players: {pop_val}**\n"
            except: pass

        header = "🚨 **SECURITY ALERT DETECTED** 🚨" if smart_everyone else "📜 **Tribe Log**"
        msg_content = f"{header} ({now}){mentions}\n{pop_str}\n" + "\n".join(formatted_entries)

        if not self.webhook_url:
            self.log("⚠️ [WEBHOOK] Discord URL not configured.")
            return

        success = False
        if config.get("log_send_photo", True):
            success = WebhookSender.send_with_image(self.webhook_url, msg_content, pil_image, "log.png")
        else:
            success = WebhookSender.send_text(self.webhook_url, msg_content)
        
        if success:
            self.log(f"✅ Report sent successfully to Discord ({now}).")
        else:
            self.log(f"❌ Error sending to Discord. Check URL.")
        
        # Enviar Ntfy y Alarma si es crítico (incluyendo Smart Log Monitoring)
        if smart_everyone or has_everyone or has_keyword:
            self._play_alarm(config)
            
            prio = "default"
            if smart_everyone or has_everyone: prio = "max"
            elif has_keyword: prio = "high"
            
            self._send_ntfy_notification(" | ".join(entries), config, priority=prio)

    def _play_alarm(self, config: dict) -> None:
        if not config.get("alarm_enabled", False): return
        alarm_file = config.get("alarm_file", "")
        if alarm_file:
            try:
                AudioPlayer.play_file(alarm_file)
            except Exception as e:
                self.log(f"⚠️ Error en alarma: {str(e)[:50]}")
    
    def _send_ntfy_notification(self, text: str, config: dict, priority: str = "default") -> None:
        topic = config.get("ntfy_topic", "").strip()
        if not topic: 
            self.log("ℹ️ [NTFY] No topic set. Skipping notification.")
            return

        try:
            # Ahora ntfy_notifier devuelve (success, debug_msg)
            if priority == "max": 
                success, debug = NtfyNotifier.send_error(topic, text, title="SECURITY BREACH DETECTED")
            elif priority == "high": 
                success, debug = NtfyNotifier.send_warning(topic, text, title="Priority Alert")
            else: 
                success, debug = NtfyNotifier.send(topic, text, title="Tribe Log")
            
            if success:
                self.log(f"✅ [NTFY] Alert sent to topic: {topic}")
            else:
                self.log(f"❌ [NTFY] Fail sending to topic: {topic}. Error: {debug}")
        except Exception as e:
            self.log(f"⚠️ [NTFY] Global critical error: {str(e)[:50]}")
    
    def _save_locally(self, entries: List[str], pil_image: Image.Image, config: dict) -> None:
        """Guarda los eventos en el historial local (JSON)."""
        if not entries: return
        
        save_img = config.get("local_save_image", True)
        for entry in entries:
            # Intentamos detectar el tipo para el icono del historial, sino usamos "LOG"
            event_type = self._detect_event_type(entry.lower()) or "log"
            
            try:
                self.event_logger.save_event(
                    event_type=event_type,
                    text=entry,
                    image=pil_image if save_img else None,
                    save_image=save_img
                )
            except Exception as e:
                self.log(f"⚠️ Error guardando local: {str(e)[:50]}")
