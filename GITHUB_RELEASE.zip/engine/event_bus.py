"""
engine/event_bus.py - Bus de eventos global para la aplicación.
Permite comunicación desacoplada entre workers y la UI.
"""

from typing import Callable, Dict, List

class EventBus:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}

    def on(self, event: str, listener: Callable):
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(listener)

    def emit(self, event: str, *args, **kwargs):
        if event in self._listeners:
            for listener in self._listeners[event]:
                try:
                    listener(*args, **kwargs)
                except Exception as e:
                    print(f"[EVENT BUS ERROR] Error en listener para {event}: {e}")

    def clear(self):
        self._listeners.clear()

# Instancia única global
bus = EventBus()
