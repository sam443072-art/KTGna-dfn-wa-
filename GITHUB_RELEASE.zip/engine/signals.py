"""
engine/signals.py - Definición de señales para el bus de eventos de la aplicación.
"""

from engine.event_bus import bus

class Signal:
    """Encapsulator para emitir señales en el bus global."""
    def __init__(self, name: str, *arg_types):
        self.name = name
        self.arg_types = arg_types

    def emit(self, *args):
        # Enviar al bus global
        bus.emit(self.name, *args)

class BotSignals:
    """Contenedor de todas las señales del bot."""
    def __init__(self):
        """Inicializa las señales para el bus de eventos de la instancia."""
        self.console_msg = Signal("log:message", str)
        self.auto_reconnect = Signal("log:auto_reconnect")
        self.update_hud = Signal("log:update_hud", str, str)
        self.notify = Signal("log:notify", str, str) # title, message
        self.close_hud = Signal("log:close_hud")
