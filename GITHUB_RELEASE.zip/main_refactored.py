import sys
import os
import flet as ft

# Agregar ruta raíz del proyecto a sys.path ANTES de los imports
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from ui.flet_app import create_app

# Configurar paths si ejecutamos desde PyInstaller (frozen)
if getattr(sys, 'frozen', False):
    os.chdir(os.path.dirname(sys.executable))

def main():
    """Punto de entrada de la aplicación Flet."""
    try:
        # Ejecutar en modo nativo
        ft.app(target=create_app)
    except Exception as e:
        print(f"❌ Error fatal al iniciar la aplicación: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
