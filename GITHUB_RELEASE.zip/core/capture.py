"""
Captura de ventanas en segundo plano.
Responsabilidad: Obtener screenshot de ARK incluso si está detrás de otras ventanas.
"""

import os
import sys
import ctypes
import pyautogui
import win32gui
import win32ui
import win32con
from PIL import Image
from typing import Optional, Tuple


class WindowCapture:
    """Utilidades para capturar ventanas, especialmente en segundo plano."""
    
    @staticmethod
    def find_window_handle(window_title: str) -> Optional[int]:
        """
        Busca el handler de una ventana por título.
        Intenta múltiples variaciones del título.
        
        Args:
            window_title: Título principal de la ventana (ej: "ArkAscended")
        
        Returns:
            Handler de la ventana o None si no la encuentra
        """
        titles = [window_title, "ARK: Survival Ascended", "ArkAscended"]
        
        for title in titles:
            hwnd = win32gui.FindWindow(None, title)
            if hwnd:
                return hwnd
        
        return None
    
    @staticmethod
    def capture_background_window(window_title: str, 
                                  region: Optional[Tuple[int, int, int, int]] = None) -> Optional[Image.Image]:
        """
        Captura una ventana específica incluso si está detrás de otras.
        Usa PrintWindow de Win32 con flag PW_RENDERFULLCONTENT.
        
        Args:
            window_title: Título de la ventana a capturar
            region: Tupla (x, y, w, h) para recortar región específica.
                   Si None, captura la ventana completa.
        
        Returns:
            Imagen PIL de la ventana, o None si falla
        """
        hwnd = WindowCapture.find_window_handle(window_title)
        if not hwnd:
            return None
        
        try:
            # Obtener dimensiones de la ventana
            left, top, right, bottom = win32gui.GetWindowRect(hwnd)
            width = right - left
            height = bottom - top
            
            # Crear contexto de dispositivo
            hwnd_dc = win32gui.GetWindowDC(hwnd)
            mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
            save_dc = mfc_dc.CreateCompatibleDC()
            
            # Crear bitmap compatible
            save_bitmap = win32ui.CreateBitmap()
            save_bitmap.CreateCompatibleBitmap(mfc_dc, width, height)
            save_dc.SelectObject(save_bitmap)
            
            # Flag 3 = PW_RENDERFULLCONTENT (captura contenido DirectX)
            ctypes.windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), 3)
            
            # Extraer información del bitmap
            bmp_info = save_bitmap.GetInfo()
            bmp_str = save_bitmap.GetBitmapBits(True)
            
            # Convertir a imagen PIL
            img = Image.frombuffer('RGB', (bmp_info['bmWidth'], bmp_info['bmHeight']),
                                  bmp_str, 'raw', 'BGRX', 0, 1)
            
            # Limpiar recursos
            win32gui.DeleteObject(save_bitmap.GetHandle())
            save_dc.DeleteDC()
            mfc_dc.DeleteDC()
            win32gui.ReleaseDC(hwnd, hwnd_dc)
            
            # Aplicar región si se especificó
            if region:
                rx, ry, rw, rh = region
                # Ajustar coordenadas relativas a la ventana
                img_x = max(0, rx - left)
                img_y = max(0, ry - top)
                img_x2 = min(img.width, img_x + rw)
                img_y2 = min(img.height, img_y + rh)
                
                if img_x < img_x2 and img_y < img_y2:
                    img = img.crop((img_x, img_y, img_x2, img_y2))
            
            return img
        
        except Exception as e:
            print(f"⚠️ Error capturando ventana: {e}")
            return None
    
    @staticmethod
    def get_screenshot_with_fallback(window_title: str,
                                     region: Optional[Tuple[int, int, int, int]] = None) -> Optional[Image.Image]:
        """
        Intenta capturar la ventana. Si falla, usa pyautogui como fallback.
        
        Args:
            window_title: Título de la ventana
            region: Región (x, y, w, h) para capturar
        
        Returns:
            Imagen PIL, o None si ambos métodos fallan
        """
        # Intentar captura de ventana en segundo plano
        img = WindowCapture.capture_background_window(window_title, region=region)
        if img is not None:
            return img
        
        # Fallback: captura normal de pantalla
        if region:
            x, y, w, h = region
            img = pyautogui.screenshot(region=(x, y, w, h))
            return img
        
        return None
    
    @staticmethod
    def is_window_visible(window_title: str) -> bool:
        """
        Verifica si una ventana está visible en pantalla.
        
        Args:
            window_title: Título de la ventana
        
        Returns:
            True si la ventana está visible
        """
        hwnd = WindowCapture.find_window_handle(window_title)
        if not hwnd:
            return False
        
        return win32gui.IsWindowVisible(hwnd)
    
    @staticmethod
    def bring_window_to_front(window_title: str) -> bool:
        """
        Intenta traer una ventana al frente de la pantalla.
        
        Args:
            window_title: Título de la ventana
        
        Returns:
            True si tiene éxito
        """
        hwnd = WindowCapture.find_window_handle(window_title)
        if not hwnd:
            return False
        
        try:
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(hwnd)
            return True
        except Exception:
            return False
