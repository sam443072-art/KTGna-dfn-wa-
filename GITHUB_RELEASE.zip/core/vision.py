"""
Motor de Visión Artificial.
Centraliza todo el preprocesamiento de imagen y OCR.
Responsabilidad: Imagen cruda → Texto OCR + metadatos
"""

import cv2
import numpy as np
import pytesseract
from typing import Tuple, Optional, Dict, Any
from PIL import Image


class VisionEngine:
    """Engine de visión que encapsula OCR y preprocesamiento."""
    
    def __init__(self):
        """Inicializa el engine de visión."""
        self._setup_tesseract()
    
    @staticmethod
    def _setup_tesseract() -> None:
        """Configura la ruta de Tesseract según el sistema."""
        import os
        import sys
        
        base_dir = os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__)
        local_path = os.path.join(base_dir, "Tesseract-OCR", "tesseract.exe")
        
        if os.path.exists(local_path):
            pytesseract.pytesseract.tesseract_cmd = local_path
            return
        
        default_path = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        if os.path.exists(default_path):
            pytesseract.pytesseract.tesseract_cmd = default_path
            return
        
        # Fallback: confiar en que está en PATH
        pytesseract.pytesseract.tesseract_cmd = "tesseract.exe"
    
    @staticmethod
    def preprocess_log_image(pil_image: Image.Image, scale_factor: float = 3.0) -> np.ndarray:
        """
        Preprocesamiento de MÁXIMO CONTRASTE para lectura de LOG.
        Convierte cualquier color de texto a BLANCO sobre NEGRO.
        """
        # 1. PIL → OpenCV
        img = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        
        # 2. ESCALADO 3X (3fx) para máxima nitidez de Tesseract
        img = cv2.resize(img, None, fx=scale_factor, fy=scale_factor, 
                        interpolation=cv2.INTER_LANCZOS4)
        
        # 3. CONVERSIÓN A GRIS (Máximo de canales para capturar todos los colores de texto)
        gray = np.max(img, axis=2)
        
        # 4. CONTRASTE EXTREMO (Normalización + Binarización)
        # Forzamos fondo negro y texto blanco sin importar el color original
        _, thresh = cv2.threshold(gray, 120, 255, cv2.THRESH_BINARY)
        
        # 5. GROSOR EXTRA (Dilatación suave para conectar píxeles de fuentes delgadas)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
        thresh = cv2.dilate(thresh, kernel, iterations=1)
        
        return thresh
    
    @staticmethod
    def preprocess_dialog_image(pil_image: Image.Image, scale_factor: float = 3.0) -> np.ndarray:
        """
        Preprocesamiento MEJORADO para diálogos y ventanas.
        Optimizado para ARK: Survival Ascended - balance ruido/texto.
        
        Características:
        - Escalado 3.0x (máxima nitidez)
        - CLAHE: Mejora de contraste local + gaussiana para suavidad
        - Threshold 175: Balance entre capturar texto y remover ruido
        - Morphological: Limpieza agresiva de ruido pequeño
        """
        # PIL -> OpenCV
        img = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        
        # Escalado LANCZOS4 para máxima nitidez
        img = cv2.resize(img, None, fx=scale_factor, fy=scale_factor,
                        interpolation=cv2.INTER_LANCZOS4)
        
        # Convertir a gris
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # MEJORA 1: Gaussian Blur para suavizar ruido
        gray = cv2.GaussianBlur(gray, (3, 3), 0)
        
        # MEJORA 2: CLAHE (Contrast Limited Adaptive Histogram Equalization)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        gray = clahe.apply(gray)
        
        # MEJORA 3: Threshold BALANCEADO (175 - punto medio)
        # 175 captura texto sin capturar tanta basura como 160
        _, thresh = cv2.threshold(gray, 175, 255, cv2.THRESH_BINARY)
        
        # MEJORA 4: Limpieza de ruido - kernel de 3x3 (Más suave para no borrar letras)
        kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel_open)
        
        # MEJORA 5: Conectar caracteres rotos - dilatación suave
        kernel_dilate = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        thresh = cv2.dilate(thresh, kernel_dilate, iterations=1)
        
        return thresh
    
    @staticmethod
    def read_text(preprocessed_image: np.ndarray) -> str:
        """
        Lee texto OCR de una imagen preprocesada.
        
        Args:
            preprocessed_image: Imagen numpy ya umbralizada
        
        Returns:
            Texto leído por OCR
        """
        text = pytesseract.image_to_string(preprocessed_image)
        return text.strip()
    
    @staticmethod
    def read_text_with_data(preprocessed_image: np.ndarray) -> Dict[str, Any]:
        """
        Lee texto OCR y retorna metadatos (posiciones, confidencias, etc).
        Útil para localizar palabras clave dentro de la imagen.
        
        Args:
            preprocessed_image: Imagen numpy ya umbralizada
        
        Returns:
            Dict con datos detallados del OCR (left, top, width, height, confidence, etc)
        """
        data = pytesseract.image_to_data(preprocessed_image, 
                                        output_type=pytesseract.Output.DICT)
        return data
    
    @staticmethod
    def find_bounding_box(data: Dict[str, Any], keyword: str) -> Optional[Tuple[int, int, int, int]]:
        """
        Encuentra el bounding box de una palabra clave en los datos OCR.
        
        Args:
            data: Dict retornado por read_text_with_data()
            keyword: Palabra a buscar
        
        Returns:
            (x, y, width, height) o None si no encuentra
        """
        keyword_low = keyword.lower()
        
        x_min, y_min, x_max, y_max = 9999, 9999, 0, 0
        found = False
        
        for i, text in enumerate(data['text']):
            if keyword_low in text.lower():
                x_min = min(x_min, data['left'][i])
                y_min = min(y_min, data['top'][i])
                x_max = max(x_max, data['left'][i] + data['width'][i])
                y_max = max(y_max, data['top'][i] + data['height'][i])
                found = True
        
        if found:
            return (x_min, y_min, x_max - x_min, y_max - y_min)
        return None
    
    # === PIPELINES COMPLETOS (para workers que no quieren compilar pasos) ===
    
    @staticmethod
    def read_log_region(pil_image: Image.Image) -> str:
        """
        Pipeline completo: PIL imagen de región LOG → Texto leído.
        
        Args:
            pil_image: Región del log
        
        Returns:
            Texto leído del log
        """
        thresh = VisionEngine.preprocess_log_image(pil_image, scale_factor=2.0)
        text = VisionEngine.read_text(thresh)
        return text
    
    @staticmethod
    def read_dialog(pil_image: Image.Image) -> str:
        """
        Pipeline completo: PIL imagen de diálogo → Texto leído.
        
        Args:
            pil_image: Imagen del diálogo
        
        Returns:
            Texto leído del diálogo
        """
        thresh = VisionEngine.preprocess_dialog_image(pil_image, scale_factor=3.0)
        text = VisionEngine.read_text(thresh)
        return text
    
    @staticmethod
    def read_screen_region(region_screenshot: np.ndarray, preset: str = "log") -> str:
        """
        Lee texto de una región de pantalla capturada como numpy array.
        
        Args:
            region_screenshot: Numpy array (OpenCV format BGR)
            preset: Preset de preprocesamiento ("log" o "dialog")
        
        Returns:
            Texto leído
        """
        if preset == "dialog":
            region_screenshot = cv2.resize(region_screenshot, None, fx=3.0, fy=3.0,
                                          interpolation=cv2.INTER_LANCZOS4)
            gray = cv2.cvtColor(region_screenshot, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
        else:  # "log" o defecto
            region_screenshot = cv2.resize(region_screenshot, None, fx=2.0, fy=2.0,
                                          interpolation=cv2.INTER_CUBIC)
            gray = np.max(region_screenshot, axis=2)
            gray = cv2.convertScaleAbs(gray, alpha=1.2, beta=10)
            _, thresh = cv2.threshold(gray, 0, 255, 
                                     cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        text = pytesseract.image_to_string(thresh)
        return text.strip()


# ════════════════════════════════════════════════════════════════════════════
# ENGINES ESPECIALIZADOS - Optimizados para casos específicos
# ════════════════════════════════════════════════════════════════════════════

class LogVisionEngine(VisionEngine):
    """
    Vision Engine especializado para lectura de LOGS.
    
    Características:
    - Escala: 2.0x (óptimo para legibilidad de texto continuo)
    - Threshold: Otsu automático (adaptativo al contenido)
    - Preprocesamiento: Contraste mejorado, máximo de canales
    
    Uso: engine/log_worker.py
    """
    
    def __init__(self):
        """Inicializa el engine especializado para logs."""
        super().__init__()
        self.scale_factor = 3.0
    
    def read(self, pil_image: Image.Image) -> str:
        """
        Lee el texto completo de una región de log.
        
        Args:
            pil_image: PIL Image de la región del log
        
        Returns:
            Texto leído del log
        """
        thresh = self.preprocess_log_image(pil_image, scale_factor=self.scale_factor)
        return self.read_text(thresh)


class DialogVisionEngine(VisionEngine):
    """
    Vision Engine especializado para lectura de DIÁLOGOS y ventanas.
    
    Características:
    - Escala: 3.0x (máxima nitidez para palabras clave)
    - Threshold: Duro (210) para aislar texto blanco puro
    - Preprocesamiento: Fondo negro + texto blanco puro
    - Morphological: MORPH_OPEN para limpiar ruido
    
    Uso: engine/disconnect_worker.py, ventanas de confirmación
    """
    
    def __init__(self):
        """Inicializa el engine especializado para diálogos."""
        super().__init__()
        self.scale_factor = 3.0
        self.threshold_value = 210  # Blanco puro
    
    def read(self, pil_image: Image.Image) -> str:
        """
        Lee el texto de un diálogo/ventana.
        
        Args:
            pil_image: PIL Image del diálogo
        
        Returns:
            Texto leído del diálogo
        """
        thresh = self.preprocess_dialog_image(pil_image, scale_factor=self.scale_factor)
        return self.read_text(thresh)
    
    def read_with_positions(self, pil_image: Image.Image) -> Dict[str, Any]:
        """
        Lee texto + retorna posiciones de cada palabra.
        Útil para localización de botones ("Accept", "Decline", etc).
        
        Args:
            pil_image: PIL Image del diálogo
        
        Returns:
            Dict con datos OCR incluyendo (left, top, width, height, text, conf)
        """
        thresh = self.preprocess_dialog_image(pil_image, scale_factor=self.scale_factor)
        return self.read_text_with_data(thresh)
    
    def find_keyword_position(self, pil_image: Image.Image, 
                             keyword: str) -> Optional[Tuple[int, int, int, int]]:
        """
        Busca una palabra clave y retorna su posición exacta.
        Útil para calcular coordenadas de click en botones.
        
        Args:
            pil_image: PIL Image del diálogo
            keyword: Palabra a buscar (e.g. "Accept", "Decline")
        
        Returns:
            (x, y, width, height) de la palabra, o None si no encuentra
        """
        data = self.read_with_positions(pil_image)
        return self.find_bounding_box(data, keyword)
