"""
updater.py - Script de reemplazo y reinicio para actualizaciones de LogBot.
"""

import time
import os
import sys
import zipfile
import shutil
import subprocess

def main():
    # 1. PEQUEÑA ESPERA: Para que el proceso principal (main_refactored.py) se cierre de verdad
    print("🔄 [UPDATER] Waiting for main app to exit...")
    time.sleep(3)
    
    update_zip = "update.zip"
    script_name = "main_refactored.py"
    
    # 2. VERIFICACIÓN DEL PAQUETE
    if not os.path.exists(update_zip):
        print("❌ [UPDATER ERROR] update.zip not found. Aborting.")
        time.sleep(5)
        return

    # 3. EXTRACCIÓN Y SOBRESCRITURA
    try:
        print("📁 [UPDATER] Extracting and replacing files...")
        with zipfile.ZipFile(update_zip, 'r') as zip_ref:
            # Extraer todo en la raíz del proyecto actual
            zip_ref.extractall(".")
        
        # Eliminar el ZIP tras extraerlo
        os.remove(update_zip)
        print("✅ [UPDATER] Update applied successfully!")
        
    except Exception as e:
        print(f"❌ [UPDATER ERROR] Extraction failed: {e}")
        time.sleep(10)
        return

    # 4. REINICIO DEL BOT
    print("🚀 [UPDATER] Restarting ArkLogApp...")
    try:
        # Abrimos el bot de nuevo como un proceso independiente
        subprocess.Popen([sys.executable, script_name])
        print("👋 [UPDATER] Mission accomplished. Closing...")
        time.sleep(1)
        sys.exit(0)
    except Exception as e:
        print(f"❌ [UPDATER ERROR] Failed to restart: {e}")
        time.sleep(10)

if __name__ == "__main__":
    main()
